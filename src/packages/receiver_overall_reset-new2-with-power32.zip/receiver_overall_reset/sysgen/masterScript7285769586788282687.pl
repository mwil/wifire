
open(PIDFILE, '> pidfile.txt') || die 'Couldn\'t write process ID to file.';
print PIDFILE "$$\n";
close(PIDFILE);

eval {
  # Call script(s).
  my $instrs;
  my $results = [];
$ENV{'SYSGEN'} = 'C:/Xilinx/12.2/ISE_DS/ISE/sysgen';
  use Sg;
  $instrs = {
    'HDLCodeGenStatus' => 0.0,
    'HDL_PATH' => 'G:/Projekte/Stefan Dyckmans - Masterarbeit/simulink',
    'TEMP' => 'C:/Users/ich/AppData/Local/Temp',
    'TMP' => 'C:/Users/ich/AppData/Local/Temp',
    'Temp' => 'C:/Users/ich/AppData/Local/Temp',
    'Tmp' => 'C:/Users/ich/AppData/Local/Temp',
    'base_system_period_hardware' => 10.0,
    'base_system_period_simulink' => 1.0,
    'block_icon_display' => 'Default',
    'block_type' => 'sysgen',
    'block_version' => '12.1',
    'ce_clr' => 0.0,
    'clock_domain' => 'default',
    'clock_loc' => '',
    'clock_wrapper' => 'Clock Enables',
    'clock_wrapper_sgadvanced' => '',
    'compilation' => 'HDL Netlist',
    'compilation_lut' => {
      'keys' => [
        'HDL Netlist',
        'Bitstream',
        'Timing and Power Analysis',
      ],
      'values' => [
        'target1',
        'target2',
        'target3',
      ],
    },
    'compilation_target' => 'HDL Netlist',
    'core_generation' => 1.0,
    'core_generation_sgadvanced' => '',
    'core_is_deployed' => 0.0,
    'coregen_core_generation_tmpdir' => 'C:/Users/ich/AppData/Local/Temp/sysgentmp-ich/cg_wk/ca4398703f9b88419',
    'coregen_part_family' => 'spartan3',
    'createTestbench' => 0,
    'dbl_ovrd' => -1.0,
    'dbl_ovrd_sgadvanced' => '',
    'dcm_input_clock_period' => 10.0,
    'deprecated_control' => 'off',
    'deprecated_control_sgadvanced' => '',
    'design' => 'receiver_overall_reset',
    'design_full_path' => 'G:\\Projekte\\Stefan Dyckmans - Masterarbeit\\simulink\\receiver_overall_reset.mdl',
    'device' => 'xc3s2000-5fg456',
    'device_speed' => '-5',
    'directory' => 'G:/Projekte/wireless_firewall/dschung/IEEE 802.15.4 receiver/receiver_overall_reset',
    'dsp_cache_root_path' => 'C:/Users/ich/AppData/Local/Temp/sysgentmp-ich',
    'eval_field' => '0',
    'fileDeliveryDefaults' => [
      [
        '(?i)\\.vhd$',
        { 'fileName' => 'G:/Projekte/wireless_firewall/dschung/IEEE 802.15.4 receiver/receiver_overall_reset/sysgen/perl_results.vhd', },
      ],
      [
        '(?i)\\.v$',
        { 'fileName' => 'G:/Projekte/wireless_firewall/dschung/IEEE 802.15.4 receiver/receiver_overall_reset/sysgen/perl_results.v', },
      ],
    ],
    'fxdptinstalled' => 0.0,
    'generateUsing71FrontEnd' => 1,
    'generating_island_subsystem_handle' => 3.0010986328125,
    'generating_subsystem_handle' => 3.0010986328125,
    'generation_directory' => 'G:/Projekte/wireless_firewall/dschung/IEEE 802.15.4 receiver/receiver_overall_reset',
    'has_advanced_control' => '0',
    'hdlDir' => 'C:/Xilinx/12.2/ISE_DS/ISE/sysgen/hdl',
    'hdlKind' => 'verilog',
    'hdl_path' => 'G:/Projekte/Stefan Dyckmans - Masterarbeit/simulink',
    'incr_netlist' => 'off',
    'incr_netlist_sgadvanced' => '',
    'infoedit' => ' System Generator',
    'isdeployed' => 0,
    'ise_version' => '12.2i',
    'master_sysgen_token_handle' => 5.0010986328125,
    'matlab' => 'C:/Program Files/MATLAB/R2010a',
    'matlab_fixedpoint' => 0.0,
    'mdlHandle' => 3.0010986328125,
    'mdlPath' => 'G:/Projekte/Stefan Dyckmans - Masterarbeit/simulink/receiver_overall_reset.mdl',
    'modelDiagnostics' => [
      {
        'count' => 3492.0,
        'isMask' => 0.0,
        'type' => 'receiver_overall_reset Total blocks',
      },
      {
        'count' => 1.0,
        'isMask' => 0.0,
        'type' => 'ComplexToRealImag',
      },
      {
        'count' => 2.0,
        'isMask' => 0.0,
        'type' => 'DiscretePulseGenerator',
      },
      {
        'count' => 677.0,
        'isMask' => 0.0,
        'type' => 'Inport',
      },
      {
        'count' => 1203.0,
        'isMask' => 0.0,
        'type' => 'Outport',
      },
      {
        'count' => 961.0,
        'isMask' => 0.0,
        'type' => 'S-Function',
      },
      {
        'count' => 615.0,
        'isMask' => 0.0,
        'type' => 'SubSystem',
      },
      {
        'count' => 17.0,
        'isMask' => 0.0,
        'type' => 'Terminator',
      },
      {
        'count' => 16.0,
        'isMask' => 0.0,
        'type' => 'ToWorkspace',
      },
      {
        'count' => 5.0,
        'isMask' => 1.0,
        'type' => 'CORDIC iteration PE',
      },
      {
        'count' => 1.0,
        'isMask' => 1.0,
        'type' => 'CORDIC parallel PE',
      },
      {
        'count' => 92.0,
        'isMask' => 1.0,
        'type' => 'Xilinx Adder/Subtracter Block',
      },
      {
        'count' => 64.0,
        'isMask' => 1.0,
        'type' => 'Xilinx Arithmetic Relational Operator Block',
      },
      {
        'count' => 27.0,
        'isMask' => 1.0,
        'type' => 'Xilinx Binary Shift Operator Block',
      },
      {
        'count' => 101.0,
        'isMask' => 1.0,
        'type' => 'Xilinx Bit Slice Extractor Block',
      },
      {
        'count' => 23.0,
        'isMask' => 1.0,
        'type' => 'Xilinx Bus Concatenator Block',
      },
      {
        'count' => 24.0,
        'isMask' => 1.0,
        'type' => 'Xilinx Bus Multiplexer Block',
      },
      {
        'count' => 1.0,
        'isMask' => 1.0,
        'type' => 'Xilinx CORDIC ATAN',
      },
      {
        'count' => 1.0,
        'isMask' => 1.0,
        'type' => 'Xilinx Complex Multiplier 3.1 Block',
      },
      {
        'count' => 110.0,
        'isMask' => 1.0,
        'type' => 'Xilinx Constant Block Block',
      },
      {
        'count' => 8.0,
        'isMask' => 1.0,
        'type' => 'Xilinx Counter Block',
      },
      {
        'count' => 303.0,
        'isMask' => 1.0,
        'type' => 'Xilinx Delay Block',
      },
      {
        'count' => 6.0,
        'isMask' => 1.0,
        'type' => 'Xilinx Down Sampler Block',
      },
      {
        'count' => 2.0,
        'isMask' => 1.0,
        'type' => 'Xilinx Gateway In Block',
      },
      {
        'count' => 17.0,
        'isMask' => 1.0,
        'type' => 'Xilinx Gateway Out Block',
      },
      {
        'count' => 8.0,
        'isMask' => 1.0,
        'type' => 'Xilinx Inverter Block',
      },
      {
        'count' => 59.0,
        'isMask' => 1.0,
        'type' => 'Xilinx Logical Block Block',
      },
      {
        'count' => 2.0,
        'isMask' => 1.0,
        'type' => 'Xilinx Multiplier Block',
      },
      {
        'count' => 10.0,
        'isMask' => 1.0,
        'type' => 'Xilinx Negate Block Block',
      },
      {
        'count' => 16.0,
        'isMask' => 1.0,
        'type' => 'Xilinx Register Block',
      },
      {
        'count' => 72.0,
        'isMask' => 1.0,
        'type' => 'Xilinx Single Port Read-Only Memory Block',
      },
      {
        'count' => 1.0,
        'isMask' => 1.0,
        'type' => 'Xilinx System Generator Block',
      },
      {
        'count' => 10.0,
        'isMask' => 1.0,
        'type' => 'Xilinx Type Converter Block',
      },
      {
        'count' => 1.0,
        'isMask' => 1.0,
        'type' => 'Xilinx Type Reinterpreter Block',
      },
      {
        'count' => 4.0,
        'isMask' => 1.0,
        'type' => 'Xilinx Up Sampler Block',
      },
      {
        'count' => 1.0,
        'isMask' => 1.0,
        'type' => 'Xilinx WaveScope Block',
      },
    ],
    'model_globals_initialized' => 1.0,
    'model_path' => 'G:/Projekte/Stefan Dyckmans - Masterarbeit/simulink/receiver_overall_reset.mdl',
    'myxilinx' => 'C:/Xilinx/12.2/ISE_DS/ISE',
    'ngc_files' => [ 'xlpersistentdff.ngc', ],
    'num_sim_cycles' => '200000',
    'package' => 'fg456',
    'part' => 'xc3s2000',
    'partFamily' => 'spartan3',
    'port_data_types_enabled' => 1.0,
    'preserve_hierarchy' => 0.0,
    'run_coregen' => 'off',
    'run_coregen_sgadvanced' => '',
    'sample_time_colors_enabled' => 1.0,
    'sampletimecolors' => 1.0,
    'sg_blockgui_xml' => '',
    'sg_icon_stat' => '51,50,-1,-1,red,beige,0,07734,right,',
    'sg_list_contents' => '',
    'sg_mask_display' => 'fprintf(\'\',\'COMMENT: begin icon graphics\');
patch([0 1 1 0 ],[0 0 1 1 ],[0.93 0.92 0.86]);
patch([0.235294 0.0784314 0.313725 0.0784314 0.235294 0.490196 0.568627 0.647059 0.921569 0.705882 0.490196 0.333333 0.568627 0.333333 0.490196 0.705882 0.921569 0.647059 0.568627 0.490196 0.235294 ],[0.1 0.26 0.5 0.74 0.9 0.9 0.82 0.9 0.9 0.68 0.9 0.74 0.5 0.26 0.1 0.32 0.1 0.1 0.18 0.1 0.1 ],[0.6 0.2 0.25]);
plot([0 1 1 0 0 ],[0 0 1 1 0 ]);
fprintf(\'\',\'COMMENT: end icon graphics\');
fprintf(\'\',\'COMMENT: begin icon text\');
fprintf(\'\',\'COMMENT: end icon text\');
',
    'sg_version' => '',
    'sggui_pos' => '-1,-1,-1,-1',
    'simulation_island_subsystem_handle' => 3.0010986328125,
    'simulink_accelerator_running' => 0.0,
    'simulink_debugger_running' => 0.0,
    'simulink_period' => 1.0,
    'speed' => '-5',
    'synthesisTool' => 'XST',
    'synthesis_language' => 'verilog',
    'synthesis_tool' => 'XST',
    'synthesis_tool_sgadvanced' => '',
    'sysclk_period' => 10.0,
    'sysgen' => 'C:/Xilinx/12.2/ISE_DS/ISE/sysgen',
    'sysgenRoot' => 'C:/Xilinx/12.2/ISE_DS/ISE/sysgen',
    'sysgenTokenSettings' => {
      'base_system_period_hardware' => 10.0,
      'base_system_period_simulink' => 1.0,
      'block_icon_display' => 'Default',
      'block_type' => 'sysgen',
      'block_version' => '12.1',
      'ce_clr' => 0.0,
      'clock_loc' => '',
      'clock_wrapper' => 'Clock Enables',
      'clock_wrapper_sgadvanced' => '',
      'compilation' => 'HDL Netlist',
      'compilation_lut' => {
        'keys' => [
          'HDL Netlist',
          'Bitstream',
          'Timing and Power Analysis',
        ],
        'values' => [
          'target1',
          'target2',
          'target3',
        ],
      },
      'core_generation' => 1.0,
      'core_generation_sgadvanced' => '',
      'coregen_part_family' => 'spartan3',
      'dbl_ovrd' => -1.0,
      'dbl_ovrd_sgadvanced' => '',
      'dcm_input_clock_period' => 10.0,
      'deprecated_control' => 'off',
      'deprecated_control_sgadvanced' => '',
      'directory' => 'G:/Projekte/wireless_firewall/dschung/IEEE 802.15.4 receiver/receiver_overall_reset',
      'eval_field' => '0',
      'has_advanced_control' => '0',
      'incr_netlist' => 'off',
      'incr_netlist_sgadvanced' => '',
      'infoedit' => ' System Generator',
      'master_sysgen_token_handle' => 5.0010986328125,
      'package' => 'fg456',
      'part' => 'xc3s2000',
      'preserve_hierarchy' => 0.0,
      'run_coregen' => 'off',
      'run_coregen_sgadvanced' => '',
      'sg_blockgui_xml' => '',
      'sg_icon_stat' => '51,50,-1,-1,red,beige,0,07734,right,',
      'sg_list_contents' => '',
      'sg_mask_display' => 'fprintf(\'\',\'COMMENT: begin icon graphics\');
patch([0 1 1 0 ],[0 0 1 1 ],[0.93 0.92 0.86]);
patch([0.235294 0.0784314 0.313725 0.0784314 0.235294 0.490196 0.568627 0.647059 0.921569 0.705882 0.490196 0.333333 0.568627 0.333333 0.490196 0.705882 0.921569 0.647059 0.568627 0.490196 0.235294 ],[0.1 0.26 0.5 0.74 0.9 0.9 0.82 0.9 0.9 0.68 0.9 0.74 0.5 0.26 0.1 0.32 0.1 0.1 0.18 0.1 0.1 ],[0.6 0.2 0.25]);
plot([0 1 1 0 0 ],[0 0 1 1 0 ]);
fprintf(\'\',\'COMMENT: end icon graphics\');
fprintf(\'\',\'COMMENT: begin icon text\');
fprintf(\'\',\'COMMENT: end icon text\');
',
      'sggui_pos' => '-1,-1,-1,-1',
      'simulation_island_subsystem_handle' => 3.0010986328125,
      'simulink_period' => 1.0,
      'speed' => '-5',
      'synthesis_language' => 'verilog',
      'synthesis_tool' => 'XST',
      'synthesis_tool_sgadvanced' => '',
      'sysclk_period' => 10.0,
      'testbench' => 0,
      'testbench_sgadvanced' => '',
      'trim_vbits' => 1.0,
      'trim_vbits_sgadvanced' => '',
      'xilinx_device' => 'xc3s2000-5fg456',
      'xilinxfamily' => 'spartan3',
    },
    'sysgen_Root' => 'C:/Xilinx/12.2/ISE_DS/ISE/sysgen',
    'systemClockPeriod' => 10.0,
    'tempdir' => 'C:/Users/ich/AppData/Local/Temp',
    'testbench' => 0,
    'testbench_sgadvanced' => '',
    'tmpDir' => 'G:/Projekte/wireless_firewall/dschung/IEEE 802.15.4 receiver/receiver_overall_reset/sysgen',
    'trim_vbits' => 1.0,
    'trim_vbits_sgadvanced' => '',
    'use_strict_names' => 1,
    'user_tips_enabled' => 0.0,
    'usertemp' => 'C:/Users/ich/AppData/Local/Temp/sysgentmp-ich',
    'using71Netlister' => 1,
    'verilog_files' => [
      'conv_pkg.v',
      'synth_reg.v',
      'synth_reg_w_init.v',
      'convert_type.v',
    ],
    'version' => '',
    'vhdl_files' => [
      'conv_pkg.vhd',
      'synth_reg.vhd',
      'synth_reg_w_init.vhd',
    ],
    'vsimtime' => '2200275.000000 ns',
    'xilinx' => 'C:/Xilinx/12.2/ISE_DS/ISE',
    'xilinx_device' => 'xc3s2000-5fg456',
    'xilinx_family' => 'spartan3',
    'xilinx_package' => 'fg456',
    'xilinx_part' => 'xc3s2000',
    'xilinxdevice' => 'xc3s2000-5fg456',
    'xilinxfamily' => 'spartan3',
    'xilinxpart' => 'xc3s2000',
  };
  push(@$results, &Sg::setAttributes($instrs));
  use SgDeliverFile;
  $instrs = {
    'collaborationName' => 'conv_pkg.v',
    'sourceFile' => 'hdl/conv_pkg.v',
    'templateKeyValues' => {},
  };
  push(@$results, &SgDeliverFile::saveCollaborationInfo($instrs));
  $instrs = {
    'collaborationName' => 'synth_reg.v',
    'sourceFile' => 'hdl/synth_reg.v',
    'templateKeyValues' => {},
  };
  push(@$results, &SgDeliverFile::saveCollaborationInfo($instrs));
  $instrs = {
    'collaborationName' => 'synth_reg_w_init.v',
    'sourceFile' => 'hdl/synth_reg_w_init.v',
    'templateKeyValues' => {},
  };
  push(@$results, &SgDeliverFile::saveCollaborationInfo($instrs));
  $instrs = {
    'collaborationName' => 'convert_type.v',
    'sourceFile' => 'hdl/convert_type.v',
    'templateKeyValues' => {},
  };
  push(@$results, &SgDeliverFile::saveCollaborationInfo($instrs));
  $instrs = {
    'collaborationName' => 'xlpersistentdff.ngc',
    'sourceFile' => 'hdl/xlpersistentdff.ngc',
    'templateKeyValues' => {},
  };
  push(@$results, &SgDeliverFile::saveCollaborationInfo($instrs));
  $instrs = {
    'collaborationName' => 'xlclockenablegenerator.v',
    'sourceFile' => 'hdl/xlclockenablegenerator.v',
    'templateKeyValues' => {},
  };
  push(@$results, &SgDeliverFile::saveCollaborationInfo($instrs));
  use SgGenerateCores;
  $instrs = [
    'SELECT Adder_Subtracter spartan3 Xilinx,_Inc. 11.0',
    '# 12.2',
    '# DEVICE spartan3',
    'CSET AINIT_Value = 0',
    'CSET A_Type = Signed',
    'CSET A_Width = 41',
    'CSET Add_Mode = Add',
    'CSET B_Constant = false',
    'CSET B_Type = Signed',
    'CSET B_Value = 0',
    'CSET B_Width = 41',
    'CSET Borrow_Sense = Active_Low',
    'CSET Bypass = false',
    'CSET Bypass_CE_Priority = Bypass_Overrides_CE',
    'CSET Bypass_Sense = Active_Low',
    'CSET CE = true',
    'CSET C_In = false',
    'CSET C_Out = false',
    'CSET Implementation = Fabric',
    'CSET Latency = 1',
    'CSET Out_Width = 41',
    'CSET SCLR = false',
    'CSET SINIT = false',
    'CSET SINIT_Value = 0',
    'CSET SSET = false',
    'CSET Sync_CE_Priority = Sync_Overrides_CE',
    'CSET Sync_Ctrl_Priority = Reset_Overrides_Set',
    'SET simulationfiles = Structural',
    'CSET component_name = addsb_11_0_0eebe60429557ce6',
    'GENERATE',
  ];
  push(@$results, &SgGenerateCores::saveXcoSequence($instrs));
  $instrs = {
    'entity_declaration_hash' => '0ef9a3584b7281393765bf05571b415c',
    'sourceFile' => 'hdl/xladdsub.v',
    'templateKeyValues' => {
      'core_component_def' => '(A, CLK, CE, S, B) /* synthesis syn_black_box */;
      input[40:0] A;
     input CLK;
     input CE;
     output[40:0] S;
     input[40:0] B;',
      'core_instance_text' => '         .a(full_a),
         .clk(clk),
         .ce(internal_ce),
         .s(core_s),
         .b(full_b)',
      'core_name0' => 'addsb_11_0_0eebe60429557ce6',
      'entity_name.0' => 'xladdsub',
      'needs_core' => 1,
    },
  };
  push(@$results, &SgDeliverFile::saveCollaborationInfo($instrs));
  $instrs = [
    'SELECT Adder_Subtracter spartan3 Xilinx,_Inc. 11.0',
    '# 12.2',
    '# DEVICE spartan3',
    'CSET AINIT_Value = 0',
    'CSET A_Type = Signed',
    'CSET A_Width = 30',
    'CSET Add_Mode = Subtract',
    'CSET B_Constant = false',
    'CSET B_Type = Signed',
    'CSET B_Value = 0',
    'CSET B_Width = 30',
    'CSET Borrow_Sense = Active_Low',
    'CSET Bypass = false',
    'CSET Bypass_CE_Priority = Bypass_Overrides_CE',
    'CSET Bypass_Sense = Active_Low',
    'CSET CE = false',
    'CSET C_In = false',
    'CSET C_Out = false',
    'CSET Implementation = Fabric',
    'CSET Latency = 0',
    'CSET Out_Width = 30',
    'CSET SCLR = false',
    'CSET SINIT = false',
    'CSET SINIT_Value = 0',
    'CSET SSET = false',
    'CSET Sync_CE_Priority = Sync_Overrides_CE',
    'CSET Sync_Ctrl_Priority = Reset_Overrides_Set',
    'SET simulationfiles = Structural',
    'CSET component_name = addsb_11_0_2fffd3633a572fdb',
    'GENERATE',
  ];
  push(@$results, &SgGenerateCores::saveXcoSequence($instrs));
  $instrs = {
    'entity_declaration_hash' => '64297257c55a6baf5185aa63b3b89a73',
    'sourceFile' => 'hdl/xladdsub.v',
    'templateKeyValues' => {
      'core_component_def' => '(A, S, B) /* synthesis syn_black_box */;
      input[29:0] A;
     output[29:0] S;
     input[29:0] B;',
      'core_instance_text' => '         .a(full_a),
         .s(core_s),
         .b(full_b)',
      'core_name0' => 'addsb_11_0_2fffd3633a572fdb',
      'entity_name.0' => 'xladdsub',
      'needs_core' => 1,
    },
  };
  push(@$results, &SgDeliverFile::saveCollaborationInfo($instrs));
  $instrs = {
    'entity_declaration_hash' => 'c4fe2145d4a0666b4ba1ed622819ce5e',
    'sourceFile' => 'C:/Xilinx/12.2/ISE_DS/ISE/sysgen/hdl/xlconvert.v',
  };
  push(@$results, &SgDeliverFile::saveCollaborationInfo($instrs));
  $instrs = {
    'entity_declaration_hash' => '8213f8ec392d475404e2bbc1d5d9de92',
    'sourceFile' => 'C:/Xilinx/12.2/ISE_DS/ISE/sysgen/hdl/xldelay.v',
  };
  push(@$results, &SgDeliverFile::saveCollaborationInfo($instrs));
  $instrs = {
    'entity_declaration_hash' => 'af8688a485cd4cee0fce2c73e0037667',
    'sourceFile' => 'C:/Xilinx/12.2/ISE_DS/ISE/sysgen/hdl/xldsamp.v',
  };
  push(@$results, &SgDeliverFile::saveCollaborationInfo($instrs));
  $instrs = {
    'entity_declaration_hash' => '6d0ee3681be94dcd0b4b78e60e3f2557',
    'sourceFile' => 'hdl/xlmcode.v',
    'templateKeyValues' => {
      'crippled_module' => '(
  input [(31 - 1):0] input_port,
  output [(31 - 1):0] output_port,
  input clk,
  input ce,
  input clr);
  wire signed [(31 - 1):0] input_port_1_40;
  assign input_port_1_40 = input_port;
  assign output_port = input_port_1_40;
endmodule
',
      'entity_name' => 'reinterpret_b0ad5286f0',
    },
  };
  push(@$results, &SgDeliverFile::deliverFile($instrs));
  $instrs = {
    'entity_declaration_hash' => '27c4e9043e71dc07237df4ccfc1330ae',
    'sourceFile' => 'C:/Xilinx/12.2/ISE_DS/ISE/sysgen/hdl/xlusamp.v',
  };
  push(@$results, &SgDeliverFile::saveCollaborationInfo($instrs));
  $instrs = {
    'entity_declaration_hash' => '193d3f824002ab0cfb292b5e2ccbe4d3',
    'sourceFile' => 'C:/Xilinx/12.2/ISE_DS/ISE/sysgen/hdl/xlconvert.v',
  };
  push(@$results, &SgDeliverFile::saveCollaborationInfo($instrs));
  $instrs = {
    'entity_declaration_hash' => '632945eee2a23bd86d126f4ccf23c240',
    'sourceFile' => 'hdl/xlmcode.v',
    'templateKeyValues' => {
      'crippled_module' => '(
  output [(16 - 1):0] op,
  input clk,
  input ce,
  input clr);
  localparam [(16 - 1):0] const_value = 16\'b0000000101001000;
  assign op = 16\'b0000000101001000;
endmodule
',
      'entity_name' => 'constant_b97daa4431',
    },
  };
  push(@$results, &SgDeliverFile::deliverFile($instrs));
  $instrs = [
    'SELECT Adder_Subtracter spartan3 Xilinx,_Inc. 11.0',
    '# 12.2',
    '# DEVICE spartan3',
    'CSET AINIT_Value = 0',
    'CSET A_Type = Unsigned',
    'CSET A_Width = 29',
    'CSET Add_Mode = Add',
    'CSET B_Constant = false',
    'CSET B_Type = Unsigned',
    'CSET B_Value = 0',
    'CSET B_Width = 29',
    'CSET Borrow_Sense = Active_Low',
    'CSET Bypass = false',
    'CSET Bypass_CE_Priority = Bypass_Overrides_CE',
    'CSET Bypass_Sense = Active_Low',
    'CSET CE = false',
    'CSET C_In = false',
    'CSET C_Out = false',
    'CSET Implementation = Fabric',
    'CSET Latency = 0',
    'CSET Out_Width = 29',
    'CSET SCLR = false',
    'CSET SINIT = false',
    'CSET SINIT_Value = 0',
    'CSET SSET = false',
    'CSET Sync_CE_Priority = Sync_Overrides_CE',
    'CSET Sync_Ctrl_Priority = Reset_Overrides_Set',
    'SET simulationfiles = Structural',
    'CSET component_name = addsb_11_0_c0310715505d4804',
    'GENERATE',
  ];
  push(@$results, &SgGenerateCores::saveXcoSequence($instrs));
  $instrs = {
    'entity_declaration_hash' => '35165a50bca52e2f0677a523b3d89fe8',
    'sourceFile' => 'hdl/xladdsub.v',
    'templateKeyValues' => {
      'core_component_def' => '(A, S, B) /* synthesis syn_black_box */;
      input[28:0] A;
     output[28:0] S;
     input[28:0] B;',
      'core_instance_text' => '         .a(full_a),
         .s(core_s),
         .b(full_b)',
      'core_name0' => 'addsb_11_0_c0310715505d4804',
      'entity_name.0' => 'xladdsub',
      'needs_core' => 1,
    },
  };
  push(@$results, &SgDeliverFile::saveCollaborationInfo($instrs));
  $instrs = [
    'SELECT Multiplier spartan3 Xilinx,_Inc. 11.2',
    '# 12.2',
    '# DEVICE spartan3',
    'CSET ccmimp = Distributed_Memory',
    'CSET clockenable = true',
    'CSET constvalue = 129',
    'CSET internaluser = 0',
    'CSET multiplier_construction = Use_Mults',
    'CSET multtype = Parallel_Multiplier',
    'CSET optgoal = Speed',
    'CSET outputwidthhigh = 29',
    'CSET outputwidthlow = 0',
    'CSET pipestages = 1',
    'CSET portatype = Signed',
    'CSET portawidth = 15',
    'CSET portbtype = Signed',
    'CSET portbwidth = 15',
    'CSET roundpoint = 0',
    'CSET sclrcepriority = CE_Overrides_SCLR',
    'CSET syncclear = true',
    'CSET use_custom_output_width = true',
    'CSET userounding = false',
    'CSET zerodetect = false',
    'CSET component_name = mult_11_2_bfb63374a454bb8d',
    'GENERATE',
  ];
  push(@$results, &SgGenerateCores::saveXcoSequence($instrs));
  $instrs = {
    'entity_declaration_hash' => 'ddd69f5899da2ddf5ceae497c42483f3',
    'sourceFile' => 'hdl/xlmult.v',
    'templateKeyValues' => {
      'core_component_def' => '(A, B, CLK, CE, SCLR, P) /* synthesis syn_black_box */;
      input [14:0] A;
      input [14:0] B;
      input CLK, CE, SCLR;
      output [29:0] P;',
      'core_instance_text' => '        .a(tmp_a),
        .b(tmp_b),
        .clk(clk),
        .ce(internal_ce),
        .sclr(internal_clr),
        .p(tmp_p)',
      'core_name0' => 'mult_11_2_bfb63374a454bb8d',
      'entity_name.0' => 'xlmult',
      'needs_core' => 1,
    },
  };
  push(@$results, &SgDeliverFile::saveCollaborationInfo($instrs));
  $instrs = {
    'entity_declaration_hash' => 'dca75338f6f1ad22bff0659515fd0149',
    'sourceFile' => 'hdl/xlmcode.v',
    'templateKeyValues' => {
      'crippled_module' => '(
  input [(32 - 1):0] a,
  input [(16 - 1):0] b,
  output [(1 - 1):0] op,
  input clk,
  input ce,
  input clr);
  wire [(32 - 1):0] a_1_31;
  wire [(16 - 1):0] b_1_34;
  reg op_mem_32_22[0:(1 - 1)];
  initial
    begin
      op_mem_32_22[0] = 1\'b0;
    end
  wire op_mem_32_22_front_din;
  wire op_mem_32_22_back;
  wire op_mem_32_22_push_front_pop_back_en;
  localparam [(1 - 1):0] const_value = 1\'b1;
  wire [(32 - 1):0] cast_18_16;
  wire result_18_3_rel;
  assign a_1_31 = a;
  assign b_1_34 = b;
  assign op_mem_32_22_back = op_mem_32_22[0];
  always @(posedge clk)
    begin:proc_op_mem_32_22
      integer i;
      if (((ce == 1\'b1) && (op_mem_32_22_push_front_pop_back_en == 1\'b1)))
        begin
          op_mem_32_22[0] <= op_mem_32_22_front_din;
        end
    end
  assign cast_18_16 = {2\'b00, b_1_34[15:0], 14\'b00000000000000};
  assign result_18_3_rel = a_1_31 > cast_18_16;
  assign op_mem_32_22_front_din = result_18_3_rel;
  assign op_mem_32_22_push_front_pop_back_en = 1\'b1;
  assign op = op_mem_32_22_back;
endmodule
',
      'entity_name' => 'relational_833e0ca4ce',
    },
  };
  push(@$results, &SgDeliverFile::deliverFile($instrs));
  $instrs = {
    'entity_declaration_hash' => 'df924a2012e09f6841957c1c820969a5',
    'sourceFile' => 'hdl/xlmcode.v',
    'templateKeyValues' => {
      'crippled_module' => '(
  input [(33 - 1):0] a,
  input [(33 - 1):0] b,
  input [(1 - 1):0] mode,
  output [(33 - 1):0] s,
  input clk,
  input ce,
  input clr);
  wire signed [(33 - 1):0] a_17_32;
  wire signed [(33 - 1):0] b_17_35;
  wire mode_17_48;
  localparam signed [(33 - 1):0] const_value = 33\'sb000000000000000000000000000000000;
  reg signed [(33 - 1):0] op_mem_91_20[0:(1 - 1)];
  initial
    begin
      op_mem_91_20[0] = 33\'b000000000000000000000000000000000;
    end
  wire signed [(33 - 1):0] op_mem_91_20_front_din;
  wire signed [(33 - 1):0] op_mem_91_20_back;
  wire op_mem_91_20_push_front_pop_back_en;
  localparam [(1 - 1):0] const_value_x_000000 = 1\'b0;
  reg [(1 - 1):0] cout_mem_92_22[0:(1 - 1)];
  initial
    begin
      cout_mem_92_22[0] = 1\'b0;
    end
  wire [(1 - 1):0] cout_mem_92_22_front_din;
  wire [(1 - 1):0] cout_mem_92_22_back;
  wire cout_mem_92_22_push_front_pop_back_en;
  wire [(3 - 1):0] prev_mode_93_22_next;
  wire [(3 - 1):0] prev_mode_93_22;
  wire [(3 - 1):0] prev_mode_93_22_reg_i;
  wire [(3 - 1):0] prev_mode_93_22_reg_o;
  localparam [(1 - 1):0] const_value_x_000001 = 1\'b0;
  localparam [(1 - 1):0] const_value_x_000002 = 1\'b1;
  localparam [(1 - 1):0] const_value_x_000003 = 1\'b0;
  localparam [(1 - 1):0] const_value_x_000004 = 1\'b0;
  wire not_68_25;
  wire bool_68_25;
  wire bool_68_7;
  wire signed [(34 - 1):0] cast_internal_s_69_5_addsub_a;
  wire signed [(34 - 1):0] cast_internal_s_69_5_addsub_b;
  reg signed [(34 - 1):0] internal_s_69_5_addsub;
  localparam [(1 - 1):0] const_value_x_000005 = 1\'b0;
  wire signed [(33 - 1):0] cast_internal_s_83_3_convert;
  localparam [(1 - 1):0] const_value_x_000006 = 1\'b0;
  wire [(3 - 1):0] prev_mode_93_22_next_x_000000;
  assign a_17_32 = a;
  assign b_17_35 = b;
  assign mode_17_48 = mode;
  assign op_mem_91_20_back = op_mem_91_20[0];
  always @(posedge clk)
    begin:proc_op_mem_91_20
      integer i;
      if (((ce == 1\'b1) && (op_mem_91_20_push_front_pop_back_en == 1\'b1)))
        begin
          op_mem_91_20[0] <= op_mem_91_20_front_din;
        end
    end
  assign cout_mem_92_22_back = cout_mem_92_22[0];
  always @(posedge clk)
    begin:proc_cout_mem_92_22
      integer i_x_000000;
      if (((ce == 1\'b1) && (cout_mem_92_22_push_front_pop_back_en == 1\'b1)))
        begin
          cout_mem_92_22[0] <= cout_mem_92_22_front_din;
        end
    end
  assign prev_mode_93_22_reg_i = prev_mode_93_22_next;
  assign prev_mode_93_22 = prev_mode_93_22_reg_o;
  defparam prev_mode_93_22_reg_inst.init_index = 2;
  defparam prev_mode_93_22_reg_inst.init_value = 3\'b010;
  defparam prev_mode_93_22_reg_inst.latency = 1;
  defparam prev_mode_93_22_reg_inst.width = 3;
  synth_reg_w_init prev_mode_93_22_reg_inst(.ce(ce), .clk(clk), .clr(clr), .i(prev_mode_93_22_reg_i), .o(prev_mode_93_22_reg_o));
  assign not_68_25 = !mode_17_48;
  assign bool_68_25 = not_68_25 && 1\'b1;
  assign bool_68_7 = 1\'b0 || bool_68_25;
  assign cast_internal_s_69_5_addsub_a = {{1{a_17_32[32]}}, a_17_32[32:0]};
  assign cast_internal_s_69_5_addsub_b = {{1{b_17_35[32]}}, b_17_35[32:0]};
  always @(bool_68_7 or cast_internal_s_69_5_addsub_a or cast_internal_s_69_5_addsub_b)
    begin:proc_internal_s_69_5_addsub
      if (bool_68_7)
        begin
          internal_s_69_5_addsub = (cast_internal_s_69_5_addsub_a + cast_internal_s_69_5_addsub_b);
        end
      else 
        begin
          internal_s_69_5_addsub = (cast_internal_s_69_5_addsub_a - cast_internal_s_69_5_addsub_b);
        end
    end
  assign cast_internal_s_83_3_convert = {internal_s_69_5_addsub[32:0]};
  assign op_mem_91_20_front_din = cast_internal_s_83_3_convert;
  assign op_mem_91_20_push_front_pop_back_en = 1\'b1;
  assign cout_mem_92_22_front_din = const_value_x_000006;
  assign cout_mem_92_22_push_front_pop_back_en = 1\'b1;
  assign prev_mode_93_22_next_x_000000 = {2\'b00, mode_17_48};
  assign prev_mode_93_22_next = prev_mode_93_22_next_x_000000;
  assign s = op_mem_91_20_back;
endmodule
',
      'entity_name' => 'addsub_76df133d19',
    },
  };
  push(@$results, &SgDeliverFile::deliverFile($instrs));
  $instrs = {
    'entity_declaration_hash' => '42b669a05dcfbfa08e64cd593797ae8d',
    'sourceFile' => 'hdl/xlmcode.v',
    'templateKeyValues' => {
      'crippled_module' => '(
  input [(33 - 1):0] a,
  input [(33 - 1):0] b,
  input [(1 - 1):0] mode,
  output [(33 - 1):0] s,
  input clk,
  input ce,
  input clr);
  wire signed [(33 - 1):0] a_17_32;
  wire signed [(33 - 1):0] b_17_35;
  wire mode_17_48;
  localparam signed [(33 - 1):0] const_value = 33\'sb000000000000000000000000000000000;
  reg signed [(33 - 1):0] op_mem_91_20[0:(1 - 1)];
  initial
    begin
      op_mem_91_20[0] = 33\'b000000000000000000000000000000000;
    end
  wire signed [(33 - 1):0] op_mem_91_20_front_din;
  wire signed [(33 - 1):0] op_mem_91_20_back;
  wire op_mem_91_20_push_front_pop_back_en;
  localparam [(1 - 1):0] const_value_x_000000 = 1\'b0;
  reg [(1 - 1):0] cout_mem_92_22[0:(1 - 1)];
  initial
    begin
      cout_mem_92_22[0] = 1\'b0;
    end
  wire [(1 - 1):0] cout_mem_92_22_front_din;
  wire [(1 - 1):0] cout_mem_92_22_back;
  wire cout_mem_92_22_push_front_pop_back_en;
  wire [(3 - 1):0] prev_mode_93_22_next;
  wire [(3 - 1):0] prev_mode_93_22;
  wire [(3 - 1):0] prev_mode_93_22_reg_i;
  wire [(3 - 1):0] prev_mode_93_22_reg_o;
  localparam [(1 - 1):0] const_value_x_000001 = 1\'b0;
  localparam [(1 - 1):0] const_value_x_000002 = 1\'b1;
  localparam [(1 - 1):0] const_value_x_000003 = 1\'b0;
  localparam [(1 - 1):0] const_value_x_000004 = 1\'b0;
  wire not_68_25;
  wire bool_68_25;
  wire bool_68_7;
  wire signed [(36 - 1):0] cast_internal_s_69_5_addsub_a;
  wire signed [(36 - 1):0] cast_internal_s_69_5_addsub_b;
  reg signed [(36 - 1):0] internal_s_69_5_addsub;
  localparam [(1 - 1):0] const_value_x_000005 = 1\'b0;
  wire signed [(33 - 1):0] cast_internal_s_83_3_convert;
  localparam [(1 - 1):0] const_value_x_000006 = 1\'b0;
  wire [(3 - 1):0] prev_mode_93_22_next_x_000000;
  assign a_17_32 = a;
  assign b_17_35 = b;
  assign mode_17_48 = mode;
  assign op_mem_91_20_back = op_mem_91_20[0];
  always @(posedge clk)
    begin:proc_op_mem_91_20
      integer i;
      if (((ce == 1\'b1) && (op_mem_91_20_push_front_pop_back_en == 1\'b1)))
        begin
          op_mem_91_20[0] <= op_mem_91_20_front_din;
        end
    end
  assign cout_mem_92_22_back = cout_mem_92_22[0];
  always @(posedge clk)
    begin:proc_cout_mem_92_22
      integer i_x_000000;
      if (((ce == 1\'b1) && (cout_mem_92_22_push_front_pop_back_en == 1\'b1)))
        begin
          cout_mem_92_22[0] <= cout_mem_92_22_front_din;
        end
    end
  assign prev_mode_93_22_reg_i = prev_mode_93_22_next;
  assign prev_mode_93_22 = prev_mode_93_22_reg_o;
  defparam prev_mode_93_22_reg_inst.init_index = 2;
  defparam prev_mode_93_22_reg_inst.init_value = 3\'b010;
  defparam prev_mode_93_22_reg_inst.latency = 1;
  defparam prev_mode_93_22_reg_inst.width = 3;
  synth_reg_w_init prev_mode_93_22_reg_inst(.ce(ce), .clk(clk), .clr(clr), .i(prev_mode_93_22_reg_i), .o(prev_mode_93_22_reg_o));
  assign not_68_25 = !mode_17_48;
  assign bool_68_25 = not_68_25 && 1\'b1;
  assign bool_68_7 = 1\'b0 || bool_68_25;
  assign cast_internal_s_69_5_addsub_a = {{1{a_17_32[32]}}, a_17_32[32:0], 2\'b00};
  assign cast_internal_s_69_5_addsub_b = {{3{b_17_35[32]}}, b_17_35[32:0]};
  always @(bool_68_7 or cast_internal_s_69_5_addsub_a or cast_internal_s_69_5_addsub_b)
    begin:proc_internal_s_69_5_addsub
      if (bool_68_7)
        begin
          internal_s_69_5_addsub = (cast_internal_s_69_5_addsub_a + cast_internal_s_69_5_addsub_b);
        end
      else 
        begin
          internal_s_69_5_addsub = (cast_internal_s_69_5_addsub_a - cast_internal_s_69_5_addsub_b);
        end
    end
  assign cast_internal_s_83_3_convert = {internal_s_69_5_addsub[32:0]};
  assign op_mem_91_20_front_din = cast_internal_s_83_3_convert;
  assign op_mem_91_20_push_front_pop_back_en = 1\'b1;
  assign cout_mem_92_22_front_din = const_value_x_000006;
  assign cout_mem_92_22_push_front_pop_back_en = 1\'b1;
  assign prev_mode_93_22_next_x_000000 = {2\'b00, mode_17_48};
  assign prev_mode_93_22_next = prev_mode_93_22_next_x_000000;
  assign s = op_mem_91_20_back;
endmodule
',
      'entity_name' => 'addsub_f7558b9b11',
    },
  };
  push(@$results, &SgDeliverFile::deliverFile($instrs));
  $instrs = {
    'entity_declaration_hash' => '5bd1737b4a366b106fbb4aa48eb780b2',
    'sourceFile' => 'hdl/xlmcode.v',
    'templateKeyValues' => {
      'crippled_module' => '(
  output [(33 - 1):0] op,
  input clk,
  input ce,
  input clr);
  localparam signed [(33 - 1):0] const_value = 33\'sb000001100100100001111110110101010;
  assign op = 33\'b000001100100100001111110110101010;
endmodule
',
      'entity_name' => 'constant_40c3d223f1',
    },
  };
  push(@$results, &SgDeliverFile::deliverFile($instrs));
  $instrs = {
    'entity_declaration_hash' => 'a9df897f6e2ec588227083c8774ca956',
    'sourceFile' => 'hdl/xlmcode.v',
    'templateKeyValues' => {
      'crippled_module' => '(
  input [(1 - 1):0] ip,
  output [(1 - 1):0] op,
  input clk,
  input ce,
  input clr);
  wire ip_1_26;
  reg op_mem_22_20[0:(1 - 1)];
  initial
    begin
      op_mem_22_20[0] = 1\'b0;
    end
  wire op_mem_22_20_front_din;
  wire op_mem_22_20_back;
  wire op_mem_22_20_push_front_pop_back_en;
  localparam [(1 - 1):0] const_value = 1\'b1;
  wire internal_ip_12_1_bitnot;
  assign ip_1_26 = ip;
  assign op_mem_22_20_back = op_mem_22_20[0];
  always @(posedge clk)
    begin:proc_op_mem_22_20
      integer i;
      if (((ce == 1\'b1) && (op_mem_22_20_push_front_pop_back_en == 1\'b1)))
        begin
          op_mem_22_20[0] <= op_mem_22_20_front_din;
        end
    end
  assign internal_ip_12_1_bitnot = ~ip_1_26;
  assign op_mem_22_20_push_front_pop_back_en = 1\'b0;
  assign op = internal_ip_12_1_bitnot;
endmodule
',
      'entity_name' => 'inverter_33a63b558a',
    },
  };
  push(@$results, &SgDeliverFile::deliverFile($instrs));
  $instrs = {
    'entity_declaration_hash' => 'ee49173bda98b4480f114331b26110b8',
    'sourceFile' => 'hdl/xlmcode.v',
    'templateKeyValues' => {
      'crippled_module' => '(
  input [(33 - 1):0] ip,
  output [(33 - 1):0] op,
  input clk,
  input ce,
  input clr);
  wire signed [(33 - 1):0] ip_1_23;
  localparam signed [(33 - 1):0] const_value = 33\'sb000000000000000000000000000000000;
  reg signed [(33 - 1):0] op_mem_46_20[0:(1 - 1)];
  initial
    begin
      op_mem_46_20[0] = 33\'b000000000000000000000000000000000;
    end
  wire signed [(33 - 1):0] op_mem_46_20_front_din;
  wire signed [(33 - 1):0] op_mem_46_20_back;
  wire op_mem_46_20_push_front_pop_back_en;
  localparam [(1 - 1):0] const_value_x_000000 = 1\'b1;
  assign ip_1_23 = ip;
  assign op_mem_46_20_back = op_mem_46_20[0];
  always @(posedge clk)
    begin:proc_op_mem_46_20
      integer i;
      if (((ce == 1\'b1) && (op_mem_46_20_push_front_pop_back_en == 1\'b1)))
        begin
          op_mem_46_20[0] <= op_mem_46_20_front_din;
        end
    end
  assign op_mem_46_20_push_front_pop_back_en = 1\'b0;
  assign op = ip_1_23;
endmodule
',
      'entity_name' => 'shift_c7ef7ac91d',
    },
  };
  push(@$results, &SgDeliverFile::deliverFile($instrs));
  $instrs = {
    'entity_declaration_hash' => '6765fff2f98fb6acd454e8b0889d4033',
    'sourceFile' => 'hdl/xlmcode.v',
    'templateKeyValues' => {
      'crippled_module' => '(
  input [(33 - 1):0] ip,
  output [(33 - 1):0] op,
  input clk,
  input ce,
  input clr);
  wire signed [(33 - 1):0] ip_1_23;
  localparam signed [(33 - 1):0] const_value = 33\'sb000000000000000000000000000000000;
  reg signed [(33 - 1):0] op_mem_46_20[0:(1 - 1)];
  initial
    begin
      op_mem_46_20[0] = 33\'b000000000000000000000000000000000;
    end
  wire signed [(33 - 1):0] op_mem_46_20_front_din;
  wire signed [(33 - 1):0] op_mem_46_20_back;
  wire op_mem_46_20_push_front_pop_back_en;
  localparam [(1 - 1):0] const_value_x_000000 = 1\'b1;
  wire signed [(33 - 1):0] cast_internal_ip_33_3_convert;
  assign ip_1_23 = ip;
  assign op_mem_46_20_back = op_mem_46_20[0];
  always @(posedge clk)
    begin:proc_op_mem_46_20
      integer i;
      if (((ce == 1\'b1) && (op_mem_46_20_push_front_pop_back_en == 1\'b1)))
        begin
          op_mem_46_20[0] <= op_mem_46_20_front_din;
        end
    end
  assign cast_internal_ip_33_3_convert = {ip_1_23[30:0], 2\'b00};
  assign op_mem_46_20_push_front_pop_back_en = 1\'b0;
  assign op = cast_internal_ip_33_3_convert;
endmodule
',
      'entity_name' => 'shift_c19d9b7899',
    },
  };
  push(@$results, &SgDeliverFile::deliverFile($instrs));
  $instrs = {
    'entity_declaration_hash' => '6bb77f6cb6bcbebc15fe4629831b3fa1',
    'sourceFile' => 'C:/Xilinx/12.2/ISE_DS/ISE/sysgen/hdl/xlslice.v',
  };
  push(@$results, &SgDeliverFile::saveCollaborationInfo($instrs));
  $instrs = {
    'entity_declaration_hash' => 'c18beb69273d14c4133a48168bab2d20',
    'sourceFile' => 'hdl/xlmcode.v',
    'templateKeyValues' => {
      'crippled_module' => '(
  output [(33 - 1):0] op,
  input clk,
  input ce,
  input clr);
  localparam signed [(33 - 1):0] const_value = 33\'sb000000111011010110001100111000001;
  assign op = 33\'b000000111011010110001100111000001;
endmodule
',
      'entity_name' => 'constant_f0d629a73b',
    },
  };
  push(@$results, &SgDeliverFile::deliverFile($instrs));
  $instrs = {
    'entity_declaration_hash' => '8448d3bcc018b34e85720ba36d13cf81',
    'sourceFile' => 'hdl/xlmcode.v',
    'templateKeyValues' => {
      'crippled_module' => '(
  input [(33 - 1):0] ip,
  output [(33 - 1):0] op,
  input clk,
  input ce,
  input clr);
  wire signed [(33 - 1):0] ip_1_23;
  localparam signed [(33 - 1):0] const_value = 33\'sb000000000000000000000000000000000;
  reg signed [(33 - 1):0] op_mem_46_20[0:(1 - 1)];
  initial
    begin
      op_mem_46_20[0] = 33\'b000000000000000000000000000000000;
    end
  wire signed [(33 - 1):0] op_mem_46_20_front_din;
  wire signed [(33 - 1):0] op_mem_46_20_back;
  wire op_mem_46_20_push_front_pop_back_en;
  localparam [(1 - 1):0] const_value_x_000000 = 1\'b1;
  wire signed [(33 - 1):0] cast_internal_ip_33_3_convert;
  assign ip_1_23 = ip;
  assign op_mem_46_20_back = op_mem_46_20[0];
  always @(posedge clk)
    begin:proc_op_mem_46_20
      integer i;
      if (((ce == 1\'b1) && (op_mem_46_20_push_front_pop_back_en == 1\'b1)))
        begin
          op_mem_46_20[0] <= op_mem_46_20_front_din;
        end
    end
  assign cast_internal_ip_33_3_convert = {{1{ip_1_23[32]}}, ip_1_23[32:1]};
  assign op_mem_46_20_push_front_pop_back_en = 1\'b0;
  assign op = cast_internal_ip_33_3_convert;
endmodule
',
      'entity_name' => 'shift_fcc487a024',
    },
  };
  push(@$results, &SgDeliverFile::deliverFile($instrs));
  $instrs = {
    'entity_declaration_hash' => '71595175739ae7e1eb5874fe75d15e04',
    'sourceFile' => 'hdl/xlmcode.v',
    'templateKeyValues' => {
      'crippled_module' => '(
  output [(33 - 1):0] op,
  input clk,
  input ce,
  input clr);
  localparam signed [(33 - 1):0] const_value = 33\'sb000000011111010110110111010111111;
  assign op = 33\'b000000011111010110110111010111111;
endmodule
',
      'entity_name' => 'constant_e29041ae0f',
    },
  };
  push(@$results, &SgDeliverFile::deliverFile($instrs));
  $instrs = {
    'entity_declaration_hash' => 'd6bfd46f938e01d8a57aed4d15f6fa6a',
    'sourceFile' => 'hdl/xlmcode.v',
    'templateKeyValues' => {
      'crippled_module' => '(
  input [(33 - 1):0] ip,
  output [(33 - 1):0] op,
  input clk,
  input ce,
  input clr);
  wire signed [(33 - 1):0] ip_1_23;
  localparam signed [(33 - 1):0] const_value = 33\'sb000000000000000000000000000000000;
  reg signed [(33 - 1):0] op_mem_46_20[0:(1 - 1)];
  initial
    begin
      op_mem_46_20[0] = 33\'b000000000000000000000000000000000;
    end
  wire signed [(33 - 1):0] op_mem_46_20_front_din;
  wire signed [(33 - 1):0] op_mem_46_20_back;
  wire op_mem_46_20_push_front_pop_back_en;
  localparam [(1 - 1):0] const_value_x_000000 = 1\'b1;
  wire signed [(33 - 1):0] cast_internal_ip_33_3_convert;
  assign ip_1_23 = ip;
  assign op_mem_46_20_back = op_mem_46_20[0];
  always @(posedge clk)
    begin:proc_op_mem_46_20
      integer i;
      if (((ce == 1\'b1) && (op_mem_46_20_push_front_pop_back_en == 1\'b1)))
        begin
          op_mem_46_20[0] <= op_mem_46_20_front_din;
        end
    end
  assign cast_internal_ip_33_3_convert = {{2{ip_1_23[32]}}, ip_1_23[32:2]};
  assign op_mem_46_20_push_front_pop_back_en = 1\'b0;
  assign op = cast_internal_ip_33_3_convert;
endmodule
',
      'entity_name' => 'shift_38ea283e41',
    },
  };
  push(@$results, &SgDeliverFile::deliverFile($instrs));
  $instrs = {
    'entity_declaration_hash' => '4feacd96fd84286950a145bf2b2365b0',
    'sourceFile' => 'hdl/xlmcode.v',
    'templateKeyValues' => {
      'crippled_module' => '(
  output [(33 - 1):0] op,
  input clk,
  input ce,
  input clr);
  localparam signed [(33 - 1):0] const_value = 33\'sb000000001111111010101101110101010;
  assign op = 33\'b000000001111111010101101110101010;
endmodule
',
      'entity_name' => 'constant_9e29304653',
    },
  };
  push(@$results, &SgDeliverFile::deliverFile($instrs));
  $instrs = {
    'entity_declaration_hash' => '8d72cb47b249db66a13fdb6f4d3ca3e6',
    'sourceFile' => 'hdl/xlmcode.v',
    'templateKeyValues' => {
      'crippled_module' => '(
  input [(33 - 1):0] ip,
  output [(33 - 1):0] op,
  input clk,
  input ce,
  input clr);
  wire signed [(33 - 1):0] ip_1_23;
  localparam signed [(33 - 1):0] const_value = 33\'sb000000000000000000000000000000000;
  reg signed [(33 - 1):0] op_mem_46_20[0:(1 - 1)];
  initial
    begin
      op_mem_46_20[0] = 33\'b000000000000000000000000000000000;
    end
  wire signed [(33 - 1):0] op_mem_46_20_front_din;
  wire signed [(33 - 1):0] op_mem_46_20_back;
  wire op_mem_46_20_push_front_pop_back_en;
  localparam [(1 - 1):0] const_value_x_000000 = 1\'b1;
  wire signed [(33 - 1):0] cast_internal_ip_33_3_convert;
  assign ip_1_23 = ip;
  assign op_mem_46_20_back = op_mem_46_20[0];
  always @(posedge clk)
    begin:proc_op_mem_46_20
      integer i;
      if (((ce == 1\'b1) && (op_mem_46_20_push_front_pop_back_en == 1\'b1)))
        begin
          op_mem_46_20[0] <= op_mem_46_20_front_din;
        end
    end
  assign cast_internal_ip_33_3_convert = {{3{ip_1_23[32]}}, ip_1_23[32:3]};
  assign op_mem_46_20_push_front_pop_back_en = 1\'b0;
  assign op = cast_internal_ip_33_3_convert;
endmodule
',
      'entity_name' => 'shift_e8fc2103b3',
    },
  };
  push(@$results, &SgDeliverFile::deliverFile($instrs));
  $instrs = {
    'entity_declaration_hash' => '19d9e79d6ffc7de6c058d2b5540b956f',
    'sourceFile' => 'hdl/xlmcode.v',
    'templateKeyValues' => {
      'crippled_module' => '(
  output [(33 - 1):0] op,
  input clk,
  input ce,
  input clr);
  localparam signed [(33 - 1):0] const_value = 33\'sb000000000111111111010101011011110;
  assign op = 33\'b000000000111111111010101011011110;
endmodule
',
      'entity_name' => 'constant_9ac1e7871e',
    },
  };
  push(@$results, &SgDeliverFile::deliverFile($instrs));
  $instrs = {
    'entity_declaration_hash' => '6babb7815ea64297d3c4f14cbaded42c',
    'sourceFile' => 'hdl/xlmcode.v',
    'templateKeyValues' => {
      'crippled_module' => '(
  output [(33 - 1):0] op,
  input clk,
  input ce,
  input clr);
  localparam signed [(33 - 1):0] const_value = 33\'sb000110010010000111111011010101001;
  assign op = 33\'b000110010010000111111011010101001;
endmodule
',
      'entity_name' => 'constant_8bb3cc6c56',
    },
  };
  push(@$results, &SgDeliverFile::deliverFile($instrs));
  $instrs = {
    'entity_declaration_hash' => '8e63301114d1c9a3018ac664fe056e1f',
    'sourceFile' => 'hdl/xlmcode.v',
    'templateKeyValues' => {
      'crippled_module' => '(
  output [(33 - 1):0] op,
  input clk,
  input ce,
  input clr);
  localparam signed [(33 - 1):0] const_value = 33\'sb111001101101111000000100101010111;
  assign op = 33\'b111001101101111000000100101010111;
endmodule
',
      'entity_name' => 'constant_13df3f0eb6',
    },
  };
  push(@$results, &SgDeliverFile::deliverFile($instrs));
  $instrs = {
    'entity_declaration_hash' => 'f2832e2d5407f546e0805d31581fb392',
    'sourceFile' => 'hdl/xlmcode.v',
    'templateKeyValues' => {
      'crippled_module' => '(
  input [(33 - 1):0] a,
  input [(33 - 1):0] b,
  output [(33 - 1):0] s,
  input clk,
  input ce,
  input clr);
  wire signed [(33 - 1):0] a_17_32;
  wire signed [(33 - 1):0] b_17_35;
  localparam signed [(33 - 1):0] const_value = 33\'sb000000000000000000000000000000000;
  reg signed [(33 - 1):0] op_mem_91_20[0:(1 - 1)];
  initial
    begin
      op_mem_91_20[0] = 33\'b000000000000000000000000000000000;
    end
  wire signed [(33 - 1):0] op_mem_91_20_front_din;
  wire signed [(33 - 1):0] op_mem_91_20_back;
  wire op_mem_91_20_push_front_pop_back_en;
  localparam [(1 - 1):0] const_value_x_000000 = 1\'b0;
  reg [(1 - 1):0] cout_mem_92_22[0:(1 - 1)];
  initial
    begin
      cout_mem_92_22[0] = 1\'b0;
    end
  wire [(1 - 1):0] cout_mem_92_22_front_din;
  wire [(1 - 1):0] cout_mem_92_22_back;
  wire cout_mem_92_22_push_front_pop_back_en;
  wire [(3 - 1):0] prev_mode_93_22_next;
  wire [(3 - 1):0] prev_mode_93_22;
  wire [(3 - 1):0] prev_mode_93_22_reg_i;
  wire [(3 - 1):0] prev_mode_93_22_reg_o;
  localparam [(1 - 1):0] const_value_x_000001 = 1\'b0;
  localparam [(1 - 1):0] const_value_x_000002 = 1\'b1;
  localparam [(1 - 1):0] const_value_x_000003 = 1\'b0;
  localparam [(1 - 1):0] const_value_x_000004 = 1\'b0;
  wire signed [(34 - 1):0] cast_71_18;
  wire signed [(34 - 1):0] cast_71_22;
  wire signed [(34 - 1):0] internal_s_71_5_addsub;
  localparam [(1 - 1):0] const_value_x_000005 = 1\'b0;
  wire signed [(33 - 1):0] cast_internal_s_83_3_convert;
  localparam [(1 - 1):0] const_value_x_000006 = 1\'b0;
  localparam [(3 - 1):0] const_value_x_000007 = 3\'b000;
  assign a_17_32 = a;
  assign b_17_35 = b;
  assign op_mem_91_20_back = op_mem_91_20[0];
  always @(posedge clk)
    begin:proc_op_mem_91_20
      integer i;
      if (((ce == 1\'b1) && (op_mem_91_20_push_front_pop_back_en == 1\'b1)))
        begin
          op_mem_91_20[0] <= op_mem_91_20_front_din;
        end
    end
  assign cout_mem_92_22_back = cout_mem_92_22[0];
  always @(posedge clk)
    begin:proc_cout_mem_92_22
      integer i_x_000000;
      if (((ce == 1\'b1) && (cout_mem_92_22_push_front_pop_back_en == 1\'b1)))
        begin
          cout_mem_92_22[0] <= cout_mem_92_22_front_din;
        end
    end
  assign prev_mode_93_22_reg_i = prev_mode_93_22_next;
  assign prev_mode_93_22 = prev_mode_93_22_reg_o;
  defparam prev_mode_93_22_reg_inst.init_index = 2;
  defparam prev_mode_93_22_reg_inst.init_value = 3\'b010;
  defparam prev_mode_93_22_reg_inst.latency = 1;
  defparam prev_mode_93_22_reg_inst.width = 3;
  synth_reg_w_init prev_mode_93_22_reg_inst(.ce(ce), .clk(clk), .clr(clr), .i(prev_mode_93_22_reg_i), .o(prev_mode_93_22_reg_o));
  assign cast_71_18 = {{1{a_17_32[32]}}, a_17_32[32:0]};
  assign cast_71_22 = {{1{b_17_35[32]}}, b_17_35[32:0]};
  assign internal_s_71_5_addsub = cast_71_18 - cast_71_22;
  assign cast_internal_s_83_3_convert = {internal_s_71_5_addsub[32:0]};
  assign op_mem_91_20_push_front_pop_back_en = 1\'b0;
  assign cout_mem_92_22_push_front_pop_back_en = 1\'b0;
  assign prev_mode_93_22_next = const_value_x_000007;
  assign s = cast_internal_s_83_3_convert;
endmodule
',
      'entity_name' => 'addsub_41ea4df8d5',
    },
  };
  push(@$results, &SgDeliverFile::deliverFile($instrs));
  $instrs = {
    'entity_declaration_hash' => 'e7c6751e1d79ab7e745ec674017af055',
    'sourceFile' => 'C:/Xilinx/12.2/ISE_DS/ISE/sysgen/hdl/xlconvert.v',
  };
  push(@$results, &SgDeliverFile::saveCollaborationInfo($instrs));
  $instrs = {
    'entity_declaration_hash' => '633a252cfb1ec800e87909f9c5761135',
    'sourceFile' => 'hdl/xlmcode.v',
    'templateKeyValues' => {
      'crippled_module' => '(
  input [(1 - 1):0] sel,
  input [(33 - 1):0] d0,
  input [(33 - 1):0] d1,
  output [(33 - 1):0] y,
  input clk,
  input ce,
  input clr);
  wire [(1 - 1):0] sel_1_20;
  wire [(33 - 1):0] d0_1_24;
  wire [(33 - 1):0] d1_1_27;
  localparam [(33 - 1):0] const_value = 33\'b000000000000000000000000000000000;
  reg [(33 - 1):0] pipe_16_22[0:(1 - 1)];
  initial
    begin
      pipe_16_22[0] = 33\'b000000000000000000000000000000000;
    end
  wire [(33 - 1):0] pipe_16_22_front_din;
  wire [(33 - 1):0] pipe_16_22_back;
  wire pipe_16_22_push_front_pop_back_en;
  reg [(33 - 1):0] unregy_join_6_1;
  assign sel_1_20 = sel;
  assign d0_1_24 = d0;
  assign d1_1_27 = d1;
  assign pipe_16_22_back = pipe_16_22[0];
  always @(posedge clk)
    begin:proc_pipe_16_22
      integer i;
      if (((ce == 1\'b1) && (pipe_16_22_push_front_pop_back_en == 1\'b1)))
        begin
          pipe_16_22[0] <= pipe_16_22_front_din;
        end
    end
  always @(d0_1_24 or d1_1_27 or sel_1_20)
    begin:proc_switch_6_1
      case (sel_1_20)
        1\'b0 :
          begin
            unregy_join_6_1 = d0_1_24;
          end
        default:
          begin
            unregy_join_6_1 = d1_1_27;
          end
      endcase
    end
  assign pipe_16_22_front_din = unregy_join_6_1;
  assign pipe_16_22_push_front_pop_back_en = 1\'b1;
  assign y = pipe_16_22_back;
endmodule
',
      'entity_name' => 'mux_d28e5457ed',
    },
  };
  push(@$results, &SgDeliverFile::deliverFile($instrs));
  $instrs = {
    'entity_declaration_hash' => '5495d965263d16f1b049d17063a4c5e0',
    'sourceFile' => 'hdl/xlmcode.v',
    'templateKeyValues' => {
      'crippled_module' => '(
  input [(1 - 1):0] sel,
  input [(33 - 1):0] d0,
  input [(33 - 1):0] d1,
  output [(33 - 1):0] y,
  input clk,
  input ce,
  input clr);
  wire sel_1_20;
  wire [(33 - 1):0] d0_1_24;
  wire [(33 - 1):0] d1_1_27;
  wire [(1 - 1):0] sel_internal_2_1_convert;
  reg [(33 - 1):0] unregy_join_6_1;
  assign sel_1_20 = sel;
  assign d0_1_24 = d0;
  assign d1_1_27 = d1;
  assign sel_internal_2_1_convert = {sel_1_20};
  always @(d0_1_24 or d1_1_27 or sel_internal_2_1_convert)
    begin:proc_switch_6_1
      case (sel_internal_2_1_convert)
        1\'b0 :
          begin
            unregy_join_6_1 = d0_1_24;
          end
        default:
          begin
            unregy_join_6_1 = d1_1_27;
          end
      endcase
    end
  assign y = unregy_join_6_1;
endmodule
',
      'entity_name' => 'mux_54f74c30cc',
    },
  };
  push(@$results, &SgDeliverFile::deliverFile($instrs));
  $instrs = {
    'entity_declaration_hash' => '6e34b26296e8805d3e77a852a8b8aecc',
    'sourceFile' => 'C:/Xilinx/12.2/ISE_DS/ISE/sysgen/hdl/xldelay.v',
  };
  push(@$results, &SgDeliverFile::saveCollaborationInfo($instrs));
  $instrs = {
    'entity_declaration_hash' => '9432fcaff5c6d663f1216a7cde80c897',
    'sourceFile' => 'C:/Xilinx/12.2/ISE_DS/ISE/sysgen/hdl/xldelay.v',
  };
  push(@$results, &SgDeliverFile::saveCollaborationInfo($instrs));
  $instrs = {
    'entity_declaration_hash' => 'da53725954582b2be7b097b42947fd8b',
    'sourceFile' => 'hdl/xlmcode.v',
    'templateKeyValues' => {
      'crippled_module' => '(
  input [(1 - 1):0] sel,
  input [(33 - 1):0] d0,
  input [(33 - 1):0] d1,
  output [(33 - 1):0] y,
  input clk,
  input ce,
  input clr);
  wire [(1 - 1):0] sel_1_20;
  wire [(33 - 1):0] d0_1_24;
  wire [(33 - 1):0] d1_1_27;
  localparam [(33 - 1):0] const_value = 33\'b000000000000000000000000000000000;
  reg [(33 - 1):0] pipe_16_22[0:(1 - 1)];
  initial
    begin
      pipe_16_22[0] = 33\'b000000000000000000000000000000000;
    end
  wire [(33 - 1):0] pipe_16_22_front_din;
  wire [(33 - 1):0] pipe_16_22_back;
  wire pipe_16_22_push_front_pop_back_en;
  reg [(35 - 1):0] unregy_join_6_1;
  wire [(33 - 1):0] cast_unregy_13_5_convert;
  assign sel_1_20 = sel;
  assign d0_1_24 = d0;
  assign d1_1_27 = d1;
  assign pipe_16_22_back = pipe_16_22[0];
  always @(posedge clk)
    begin:proc_pipe_16_22
      integer i;
      if (((ce == 1\'b1) && (pipe_16_22_push_front_pop_back_en == 1\'b1)))
        begin
          pipe_16_22[0] <= pipe_16_22_front_din;
        end
    end
  always @(d0_1_24 or d1_1_27 or sel_1_20)
    begin:proc_switch_6_1
      case (sel_1_20)
        1\'b0 :
          begin
            unregy_join_6_1 = {d0_1_24[32:0], 2\'b00};
          end
        default:
          begin
            unregy_join_6_1 = {{2{d1_1_27[32]}}, d1_1_27[32:0]};
          end
      endcase
    end
  assign cast_unregy_13_5_convert = {unregy_join_6_1[32:0]};
  assign pipe_16_22_front_din = cast_unregy_13_5_convert;
  assign pipe_16_22_push_front_pop_back_en = 1\'b1;
  assign y = pipe_16_22_back;
endmodule
',
      'entity_name' => 'mux_74faec5493',
    },
  };
  push(@$results, &SgDeliverFile::deliverFile($instrs));
  $instrs = {
    'entity_declaration_hash' => '045dd97ef18920402643ab14c714d1df',
    'sourceFile' => 'hdl/xlmcode.v',
    'templateKeyValues' => {
      'crippled_module' => '(
  input [(33 - 1):0] ip,
  output [(33 - 1):0] op,
  input clk,
  input ce,
  input clr);
  wire signed [(33 - 1):0] ip_18_25;
  localparam signed [(33 - 1):0] const_value = 33\'sb000000000000000000000000000000000;
  reg signed [(33 - 1):0] op_mem_42_20[0:(1 - 1)];
  initial
    begin
      op_mem_42_20[0] = 33\'b000000000000000000000000000000000;
    end
  wire signed [(33 - 1):0] op_mem_42_20_front_din;
  wire signed [(33 - 1):0] op_mem_42_20_back;
  wire op_mem_42_20_push_front_pop_back_en;
  localparam [(1 - 1):0] const_value_x_000000 = 1\'b1;
  wire signed [(34 - 1):0] cast_30_16;
  wire signed [(34 - 1):0] internal_ip_30_1_neg;
  wire signed [(33 - 1):0] cast_internal_ip_34_3_convert;
  assign ip_18_25 = ip;
  assign op_mem_42_20_back = op_mem_42_20[0];
  always @(posedge clk)
    begin:proc_op_mem_42_20
      integer i;
      if (((ce == 1\'b1) && (op_mem_42_20_push_front_pop_back_en == 1\'b1)))
        begin
          op_mem_42_20[0] <= op_mem_42_20_front_din;
        end
    end
  assign cast_30_16 = {{1{ip_18_25[32]}}, ip_18_25[32:0]};
  assign internal_ip_30_1_neg = -cast_30_16;
  assign cast_internal_ip_34_3_convert = {internal_ip_30_1_neg[30:0], 2\'b00};
  assign op_mem_42_20_push_front_pop_back_en = 1\'b0;
  assign op = cast_internal_ip_34_3_convert;
endmodule
',
      'entity_name' => 'negate_91c63bc363',
    },
  };
  push(@$results, &SgDeliverFile::deliverFile($instrs));
  $instrs = {
    'entity_declaration_hash' => 'e6fcf7e3e3ed875f792e44ac5e2987bf',
    'sourceFile' => 'C:/Xilinx/12.2/ISE_DS/ISE/sysgen/hdl/xldelay.v',
  };
  push(@$results, &SgDeliverFile::saveCollaborationInfo($instrs));
  $instrs = {
    'entity_declaration_hash' => '947b134ff495d6d71d52d791a1a78f40',
    'sourceFile' => 'C:/Xilinx/12.2/ISE_DS/ISE/sysgen/hdl/xldelay.v',
  };
  push(@$results, &SgDeliverFile::saveCollaborationInfo($instrs));
  $instrs = {
    'entity_declaration_hash' => '3df07e901af9219d62e7db40000d623d',
    'sourceFile' => 'hdl/xlmcode.v',
    'templateKeyValues' => {
      'crippled_module' => '(
  output [(33 - 1):0] op,
  input clk,
  input ce,
  input clr);
  localparam signed [(33 - 1):0] const_value = 33\'sb000000000000000000000000000000000;
  assign op = 33\'b000000000000000000000000000000000;
endmodule
',
      'entity_name' => 'constant_61652670f7',
    },
  };
  push(@$results, &SgDeliverFile::deliverFile($instrs));
  $instrs = [
    'SELECT Complex_Multiplier spartan3 Xilinx,_Inc. 3.1',
    '# 12.2',
    '# DEVICE spartan3',
    'CSET aportwidth = 15',
    'CSET bportwidth = 15',
    'CSET clockenable = true',
    'CSET latency = -1',
    'CSET multtype = Use_Mults',
    'CSET optimizegoal = Performance',
    'CSET outputwidthhigh = 32',
    'CSET outputwidthlow = 0',
    'CSET roundmode = Truncate',
    'CSET sclrcepriority = SCLR_overrides_CE',
    'CSET syncclear = false',
    'CSET component_name = cmpy_v3_1_0bcb403765216dc7',
    'GENERATE',
  ];
  push(@$results, &SgGenerateCores::saveXcoSequence($instrs));
  $instrs = {
    'entity_declaration_hash' => 'e66a7df62812aac97ce06b4706e0b3c0',
    'sourceFile' => 'hdl/xlmcode.v',
    'templateKeyValues' => {
      'crippled_module' => '(ai,ar,bi,br,ce,clk,pi,pr);

input[14:0] ai;
input[14:0] ar;
input[14:0] bi;
input[14:0] br;
input ce;
input clk;
output[32:0] pi;
output[32:0] pr;
  cmpy_v3_1_0bcb403765216dc7 cmpy_v3_1_0bcb403765216dc7_instance(
      .ai(ai),
      .ar(ar),
      .bi(bi),
      .br(br),
      .ce(ce),
      .clk(clk),
      .pi(pi),
      .pr(pr)
    );

 endmodule
',
      'entity_name' => 'xlcomplex_multiplier_419e13ee81f69930f3f126f1e0a72bf8',
    },
  };
  push(@$results, &SgDeliverFile::deliverFile($instrs));
  $instrs = {
    'entity_declaration_hash' => 'f8493a6915d45daa62f81275433cf3d5',
    'sourceFile' => 'C:/Xilinx/12.2/ISE_DS/ISE/sysgen/hdl/xldelay.v',
  };
  push(@$results, &SgDeliverFile::saveCollaborationInfo($instrs));
  $instrs = {
    'entity_declaration_hash' => 'ef365ddaab151830ebe53849554c1d3f',
    'sourceFile' => 'C:/Xilinx/12.2/ISE_DS/ISE/sysgen/hdl/xldsamp.v',
  };
  push(@$results, &SgDeliverFile::saveCollaborationInfo($instrs));
  $instrs = {
    'entity_declaration_hash' => '8424e90cdde20bd1fbd2f1cbce7b2817',
    'sourceFile' => 'hdl/xlmcode.v',
    'templateKeyValues' => {
      'crippled_module' => '(
  input [(1 - 1):0] ip,
  output [(1 - 1):0] op,
  input clk,
  input ce,
  input clr);
  wire [(1 - 1):0] ip_1_26;
  localparam [(1 - 1):0] const_value = 1\'b0;
  reg [(1 - 1):0] op_mem_22_20[0:(1 - 1)];
  initial
    begin
      op_mem_22_20[0] = 1\'b0;
    end
  wire [(1 - 1):0] op_mem_22_20_front_din;
  wire [(1 - 1):0] op_mem_22_20_back;
  wire op_mem_22_20_push_front_pop_back_en;
  localparam [(1 - 1):0] const_value_x_000000 = 1\'b1;
  wire [(1 - 1):0] internal_ip_12_1_bitnot;
  assign ip_1_26 = ip;
  assign op_mem_22_20_back = op_mem_22_20[0];
  always @(posedge clk)
    begin:proc_op_mem_22_20
      integer i;
      if (((ce == 1\'b1) && (op_mem_22_20_push_front_pop_back_en == 1\'b1)))
        begin
          op_mem_22_20[0] <= op_mem_22_20_front_din;
        end
    end
  assign internal_ip_12_1_bitnot = ~ip_1_26;
  assign op_mem_22_20_push_front_pop_back_en = 1\'b0;
  assign op = internal_ip_12_1_bitnot;
endmodule
',
      'entity_name' => 'inverter_e572930918',
    },
  };
  push(@$results, &SgDeliverFile::deliverFile($instrs));
  $instrs = {
    'entity_declaration_hash' => '585a296853439104d6da77fa8a193d7c',
    'sourceFile' => 'hdl/xlmcode.v',
    'templateKeyValues' => {
      'crippled_module' => '(
  input [(15 - 1):0] ip,
  output [(15 - 1):0] op,
  input clk,
  input ce,
  input clr);
  wire signed [(15 - 1):0] ip_18_25;
  localparam signed [(15 - 1):0] const_value = 15\'sb000000000000000;
  reg signed [(15 - 1):0] op_mem_42_20[0:(1 - 1)];
  initial
    begin
      op_mem_42_20[0] = 15\'b000000000000000;
    end
  wire signed [(15 - 1):0] op_mem_42_20_front_din;
  wire signed [(15 - 1):0] op_mem_42_20_back;
  wire op_mem_42_20_push_front_pop_back_en;
  localparam [(1 - 1):0] const_value_x_000000 = 1\'b1;
  wire signed [(16 - 1):0] cast_30_16;
  wire signed [(16 - 1):0] internal_ip_30_1_neg;
  wire signed [(15 - 1):0] cast_internal_ip_34_3_convert;
  assign ip_18_25 = ip;
  assign op_mem_42_20_back = op_mem_42_20[0];
  always @(posedge clk)
    begin:proc_op_mem_42_20
      integer i;
      if (((ce == 1\'b1) && (op_mem_42_20_push_front_pop_back_en == 1\'b1)))
        begin
          op_mem_42_20[0] <= op_mem_42_20_front_din;
        end
    end
  assign cast_30_16 = {{1{ip_18_25[14]}}, ip_18_25[14:0]};
  assign internal_ip_30_1_neg = -cast_30_16;
  assign cast_internal_ip_34_3_convert = {internal_ip_30_1_neg[14:0]};
  assign op_mem_42_20_push_front_pop_back_en = 1\'b0;
  assign op = cast_internal_ip_34_3_convert;
endmodule
',
      'entity_name' => 'negate_637e8d3e27',
    },
  };
  push(@$results, &SgDeliverFile::deliverFile($instrs));
  $instrs = [
    'SELECT Adder_Subtracter spartan3 Xilinx,_Inc. 11.0',
    '# 12.2',
    '# DEVICE spartan3',
    'CSET AINIT_Value = 0',
    'CSET A_Type = Signed',
    'CSET A_Width = 24',
    'CSET Add_Mode = Add',
    'CSET B_Constant = false',
    'CSET B_Type = Signed',
    'CSET B_Value = 0',
    'CSET B_Width = 24',
    'CSET Borrow_Sense = Active_Low',
    'CSET Bypass = false',
    'CSET Bypass_CE_Priority = Bypass_Overrides_CE',
    'CSET Bypass_Sense = Active_Low',
    'CSET CE = false',
    'CSET C_In = false',
    'CSET C_Out = false',
    'CSET Implementation = Fabric',
    'CSET Latency = 0',
    'CSET Out_Width = 24',
    'CSET SCLR = false',
    'CSET SINIT = false',
    'CSET SINIT_Value = 0',
    'CSET SSET = false',
    'CSET Sync_CE_Priority = Sync_Overrides_CE',
    'CSET Sync_Ctrl_Priority = Reset_Overrides_Set',
    'SET simulationfiles = Structural',
    'CSET component_name = addsb_11_0_a0fc8fc76c57c014',
    'GENERATE',
  ];
  push(@$results, &SgGenerateCores::saveXcoSequence($instrs));
  $instrs = {
    'entity_declaration_hash' => '03a36fe5ba5e310857e014808ae12e04',
    'sourceFile' => 'hdl/xladdsub.v',
    'templateKeyValues' => {
      'core_component_def' => '(A, S, B) /* synthesis syn_black_box */;
      input[23:0] A;
     output[23:0] S;
     input[23:0] B;',
      'core_instance_text' => '         .a(full_a),
         .s(core_s),
         .b(full_b)',
      'core_name0' => 'addsb_11_0_a0fc8fc76c57c014',
      'entity_name.0' => 'xladdsub',
      'needs_core' => 1,
    },
  };
  push(@$results, &SgDeliverFile::saveCollaborationInfo($instrs));
  $instrs = {
    'entity_declaration_hash' => 'b2d0eaf763e8daa0db70171714827bc0',
    'sourceFile' => 'hdl/xlmcode.v',
    'templateKeyValues' => {
      'crippled_module' => '(
  output [(7 - 1):0] op,
  input clk,
  input ce,
  input clr);
  localparam [(7 - 1):0] const_value = 7\'b0000000;
  assign op = 7\'b0000000;
endmodule
',
      'entity_name' => 'constant_2c7ec15408',
    },
  };
  push(@$results, &SgDeliverFile::deliverFile($instrs));
  $instrs = {
    'entity_declaration_hash' => '29814c642cda0e26333a2b2a6af6f723',
    'sourceFile' => 'hdl/xlmcode.v',
    'templateKeyValues' => {
      'crippled_module' => '(
  output [(16 - 1):0] op,
  input clk,
  input ce,
  input clr);
  localparam signed [(16 - 1):0] const_value = 16\'sb0100000000000000;
  assign op = 16\'b0100000000000000;
endmodule
',
      'entity_name' => 'constant_f3e8c636e8',
    },
  };
  push(@$results, &SgDeliverFile::deliverFile($instrs));
  $instrs = {
    'entity_declaration_hash' => 'e2f46fe2eac3fbb74841b5e79d0adc81',
    'sourceFile' => 'hdl/xlmcode.v',
    'templateKeyValues' => {
      'crippled_module' => '(
  input [(1 - 1):0] sel,
  input [(7 - 1):0] d0,
  input [(24 - 1):0] d1,
  output [(8 - 1):0] y,
  input clk,
  input ce,
  input clr);
  wire sel_1_20;
  wire [(7 - 1):0] d0_1_24;
  wire [(24 - 1):0] d1_1_27;
  wire [(1 - 1):0] sel_internal_2_1_convert;
  reg [(24 - 1):0] unregy_join_6_1;
  wire [(8 - 1):0] cast_unregy_13_5_convert;
  assign sel_1_20 = sel;
  assign d0_1_24 = d0;
  assign d1_1_27 = d1;
  assign sel_internal_2_1_convert = {sel_1_20};
  always @(d0_1_24 or d1_1_27 or sel_internal_2_1_convert)
    begin:proc_switch_6_1
      case (sel_internal_2_1_convert)
        1\'b0 :
          begin
            unregy_join_6_1 = {3\'b000, d0_1_24[6:0], 14\'b00000000000000};
          end
        default:
          begin
            unregy_join_6_1 = d1_1_27;
          end
      endcase
    end
  assign cast_unregy_13_5_convert = {unregy_join_6_1[21:14]};
  assign y = cast_unregy_13_5_convert;
endmodule
',
      'entity_name' => 'mux_08e6675f07',
    },
  };
  push(@$results, &SgDeliverFile::deliverFile($instrs));
  $instrs = {
    'entity_declaration_hash' => '037aa4e3bdde0bf789f40038aaefdbdf',
    'sourceFile' => 'hdl/xlmcode.v',
    'templateKeyValues' => {
      'crippled_module' => '(
  input [(1 - 1):0] d0,
  input [(1 - 1):0] d1,
  output [(1 - 1):0] y,
  input clk,
  input ce,
  input clr);
  wire d0_1_24;
  wire d1_1_27;
  wire fully_2_1_bit;
  assign d0_1_24 = d0;
  assign d1_1_27 = d1;
  assign fully_2_1_bit = d0_1_24 & d1_1_27;
  assign y = fully_2_1_bit;
endmodule
',
      'entity_name' => 'logical_28d385d867',
    },
  };
  push(@$results, &SgDeliverFile::deliverFile($instrs));
  $instrs = {
    'entity_declaration_hash' => '8c09a7edc30327cd026f633e6c57c156',
    'sourceFile' => 'hdl/xlmcode.v',
    'templateKeyValues' => {
      'crippled_module' => '(
  output [(8 - 1):0] op,
  input clk,
  input ce,
  input clr);
  localparam [(8 - 1):0] const_value = 8\'b10100111;
  assign op = 8\'b10100111;
endmodule
',
      'entity_name' => 'constant_5ca80578b0',
    },
  };
  push(@$results, &SgDeliverFile::deliverFile($instrs));
  $instrs = {
    'entity_declaration_hash' => '5680c097d51321de62b516b6239a9e1a',
    'sourceFile' => 'hdl/xlmcode.v',
    'templateKeyValues' => {
      'crippled_module' => '(
  input [(8 - 1):0] a,
  input [(8 - 1):0] b,
  output [(1 - 1):0] op,
  input clk,
  input ce,
  input clr);
  wire [(8 - 1):0] a_1_31;
  wire [(8 - 1):0] b_1_34;
  localparam [(1 - 1):0] const_value = 1\'b1;
  wire result_12_3_rel;
  assign a_1_31 = a;
  assign b_1_34 = b;
  assign result_12_3_rel = a_1_31 == b_1_34;
  assign op = result_12_3_rel;
endmodule
',
      'entity_name' => 'relational_26188fc5c4',
    },
  };
  push(@$results, &SgDeliverFile::deliverFile($instrs));
  $instrs = [
    'SELECT Adder_Subtracter spartan3 Xilinx,_Inc. 11.0',
    '# 12.2',
    '# DEVICE spartan3',
    'CSET AINIT_Value = 0',
    'CSET A_Type = Unsigned',
    'CSET A_Width = 4',
    'CSET Add_Mode = Add',
    'CSET B_Constant = false',
    'CSET B_Type = Unsigned',
    'CSET B_Value = 0',
    'CSET B_Width = 4',
    'CSET Borrow_Sense = Active_Low',
    'CSET Bypass = false',
    'CSET Bypass_CE_Priority = Bypass_Overrides_CE',
    'CSET Bypass_Sense = Active_Low',
    'CSET CE = false',
    'CSET C_In = false',
    'CSET C_Out = false',
    'CSET Implementation = Fabric',
    'CSET Latency = 0',
    'CSET Out_Width = 4',
    'CSET SCLR = false',
    'CSET SINIT = false',
    'CSET SINIT_Value = 0',
    'CSET SSET = false',
    'CSET Sync_CE_Priority = Sync_Overrides_CE',
    'CSET Sync_Ctrl_Priority = Reset_Overrides_Set',
    'SET simulationfiles = Structural',
    'CSET component_name = addsb_11_0_7321a1c531c507a8',
    'GENERATE',
  ];
  push(@$results, &SgGenerateCores::saveXcoSequence($instrs));
  $instrs = {
    'entity_declaration_hash' => '26498fee9a29c7c25f2bcbe6de5e1bc6',
    'sourceFile' => 'hdl/xladdsub.v',
    'templateKeyValues' => {
      'core_component_def' => '(A, S, B) /* synthesis syn_black_box */;
      input[3:0] A;
     output[3:0] S;
     input[3:0] B;',
      'core_instance_text' => '         .a(full_a),
         .s(core_s),
         .b(full_b)',
      'core_name0' => 'addsb_11_0_7321a1c531c507a8',
      'entity_name.0' => 'xladdsub',
      'needs_core' => 1,
    },
  };
  push(@$results, &SgDeliverFile::saveCollaborationInfo($instrs));
  $instrs = [
    'SELECT Adder_Subtracter spartan3 Xilinx,_Inc. 11.0',
    '# 12.2',
    '# DEVICE spartan3',
    'CSET AINIT_Value = 0',
    'CSET A_Type = Unsigned',
    'CSET A_Width = 5',
    'CSET Add_Mode = Add',
    'CSET B_Constant = false',
    'CSET B_Type = Unsigned',
    'CSET B_Value = 0',
    'CSET B_Width = 5',
    'CSET Borrow_Sense = Active_Low',
    'CSET Bypass = false',
    'CSET Bypass_CE_Priority = Bypass_Overrides_CE',
    'CSET Bypass_Sense = Active_Low',
    'CSET CE = false',
    'CSET C_In = false',
    'CSET C_Out = false',
    'CSET Implementation = Fabric',
    'CSET Latency = 0',
    'CSET Out_Width = 5',
    'CSET SCLR = false',
    'CSET SINIT = false',
    'CSET SINIT_Value = 0',
    'CSET SSET = false',
    'CSET Sync_CE_Priority = Sync_Overrides_CE',
    'CSET Sync_Ctrl_Priority = Reset_Overrides_Set',
    'SET simulationfiles = Structural',
    'CSET component_name = addsb_11_0_dabf7bcef017c440',
    'GENERATE',
  ];
  push(@$results, &SgGenerateCores::saveXcoSequence($instrs));
  $instrs = {
    'entity_declaration_hash' => 'a2c08e113d494e853c900da9cb108a04',
    'sourceFile' => 'hdl/xladdsub.v',
    'templateKeyValues' => {
      'core_component_def' => '(A, S, B) /* synthesis syn_black_box */;
      input[4:0] A;
     output[4:0] S;
     input[4:0] B;',
      'core_instance_text' => '         .a(full_a),
         .s(core_s),
         .b(full_b)',
      'core_name0' => 'addsb_11_0_dabf7bcef017c440',
      'entity_name.0' => 'xladdsub',
      'needs_core' => 1,
    },
  };
  push(@$results, &SgDeliverFile::saveCollaborationInfo($instrs));
  $instrs = [
    'SELECT Adder_Subtracter spartan3 Xilinx,_Inc. 11.0',
    '# 12.2',
    '# DEVICE spartan3',
    'CSET AINIT_Value = 0',
    'CSET A_Type = Unsigned',
    'CSET A_Width = 6',
    'CSET Add_Mode = Add',
    'CSET B_Constant = false',
    'CSET B_Type = Unsigned',
    'CSET B_Value = 0',
    'CSET B_Width = 6',
    'CSET Borrow_Sense = Active_Low',
    'CSET Bypass = false',
    'CSET Bypass_CE_Priority = Bypass_Overrides_CE',
    'CSET Bypass_Sense = Active_Low',
    'CSET CE = false',
    'CSET C_In = false',
    'CSET C_Out = false',
    'CSET Implementation = Fabric',
    'CSET Latency = 0',
    'CSET Out_Width = 6',
    'CSET SCLR = false',
    'CSET SINIT = false',
    'CSET SINIT_Value = 0',
    'CSET SSET = false',
    'CSET Sync_CE_Priority = Sync_Overrides_CE',
    'CSET Sync_Ctrl_Priority = Reset_Overrides_Set',
    'SET simulationfiles = Structural',
    'CSET component_name = addsb_11_0_0a06012f31241c86',
    'GENERATE',
  ];
  push(@$results, &SgGenerateCores::saveXcoSequence($instrs));
  $instrs = {
    'entity_declaration_hash' => '3898be3f89f9bcf1a490689bb112cbaa',
    'sourceFile' => 'hdl/xladdsub.v',
    'templateKeyValues' => {
      'core_component_def' => '(A, S, B) /* synthesis syn_black_box */;
      input[5:0] A;
     output[5:0] S;
     input[5:0] B;',
      'core_instance_text' => '         .a(full_a),
         .s(core_s),
         .b(full_b)',
      'core_name0' => 'addsb_11_0_0a06012f31241c86',
      'entity_name.0' => 'xladdsub',
      'needs_core' => 1,
    },
  };
  push(@$results, &SgDeliverFile::saveCollaborationInfo($instrs));
  $instrs = [
    'SELECT Distributed_Memory_Generator spartan3 Xilinx,_Inc. 5.1',
    '# 12.2',
    '# DEVICE spartan3',
    'CSET ce_overrides = sync_controls_overrides_ce',
    'CSET coefficient_file = [
',
    '  MEMORY_INITIALIZATION_RADIX = 16;',
    '  MEMORY_INITIALIZATION_VECTOR = 0, 1, 1, 2, 1, 2, 2, 3, 1, 2, 2, 3, 2, 3, 3, 4;',
    '
]',
    'CSET common_output_ce = false',
    'CSET common_output_clk = false',
    'CSET data_width = 3',
    'CSET default_data = 0',
    'CSET default_data_radix = 16',
    'CSET depth = 16',
    'CSET dual_port_address = non_registered',
    'CSET dual_port_output_clock_enable = false',
    'CSET input_clock_enable = false',
    'CSET input_options = non_registered',
    'CSET memory_type = rom',
    'CSET output_options = non_registered',
    'CSET qualify_we_with_i_ce = false',
    'CSET reset_qdpo = false',
    'CSET reset_qspo = false',
    'CSET single_port_output_clock_enable = false',
    'CSET sync_reset_qdpo = false',
    'CSET sync_reset_qspo = false',
    'CSET component_name = dmg_51_3e4449e880bf2c97',
    'GENERATE',
  ];
  push(@$results, &SgGenerateCores::saveXcoSequence($instrs));
  $instrs = {
    'entity_declaration_hash' => '1417e4659810a3e3bbdd056e3df49046',
    'sourceFile' => 'hdl/xlsprom_dist.v',
    'templateKeyValues' => {
      'core_instance_text' => '         .a(core_addr),
        .spo(core_data_out)',
      'core_name0' => 'dmg_51_3e4449e880bf2c97',
      'entity_name.0' => 'xlsprom_dist',
      'needs_core' => 1,
    },
  };
  push(@$results, &SgDeliverFile::saveCollaborationInfo($instrs));
  $instrs = {
    'entity_declaration_hash' => '59e559c08cf026278b48e6657d47ab25',
    'sourceFile' => 'C:/Xilinx/12.2/ISE_DS/ISE/sysgen/hdl/xlslice.v',
  };
  push(@$results, &SgDeliverFile::saveCollaborationInfo($instrs));
  $instrs = {
    'entity_declaration_hash' => '98e502f074c8a594aac25f81a725224d',
    'sourceFile' => 'C:/Xilinx/12.2/ISE_DS/ISE/sysgen/hdl/xlslice.v',
  };
  push(@$results, &SgDeliverFile::saveCollaborationInfo($instrs));
  $instrs = {
    'entity_declaration_hash' => '53d0f3c6edd5c75a6d12f5ad16dce0be',
    'sourceFile' => 'C:/Xilinx/12.2/ISE_DS/ISE/sysgen/hdl/xlslice.v',
  };
  push(@$results, &SgDeliverFile::saveCollaborationInfo($instrs));
  $instrs = {
    'entity_declaration_hash' => 'a6dbd5274028013994a7d0bf180a77e8',
    'sourceFile' => 'C:/Xilinx/12.2/ISE_DS/ISE/sysgen/hdl/xlslice.v',
  };
  push(@$results, &SgDeliverFile::saveCollaborationInfo($instrs));
  $instrs = {
    'entity_declaration_hash' => 'eb0108a955ac24f0ce375a159bba275e',
    'sourceFile' => 'C:/Xilinx/12.2/ISE_DS/ISE/sysgen/hdl/xlslice.v',
  };
  push(@$results, &SgDeliverFile::saveCollaborationInfo($instrs));
  $instrs = {
    'entity_declaration_hash' => '7ba664ac9327e58741571db515e10c8d',
    'sourceFile' => 'C:/Xilinx/12.2/ISE_DS/ISE/sysgen/hdl/xlslice.v',
  };
  push(@$results, &SgDeliverFile::saveCollaborationInfo($instrs));
  $instrs = {
    'entity_declaration_hash' => '0dac2b04c15a5ead53a840151de72315',
    'sourceFile' => 'C:/Xilinx/12.2/ISE_DS/ISE/sysgen/hdl/xlslice.v',
  };
  push(@$results, &SgDeliverFile::saveCollaborationInfo($instrs));
  $instrs = {
    'entity_declaration_hash' => '68372d94f491659110f3267e88793e20',
    'sourceFile' => 'C:/Xilinx/12.2/ISE_DS/ISE/sysgen/hdl/xlslice.v',
  };
  push(@$results, &SgDeliverFile::saveCollaborationInfo($instrs));
  $instrs = {
    'entity_declaration_hash' => '12d153b6d16ad54fa92cbee93b58782b',
    'sourceFile' => 'C:/Xilinx/12.2/ISE_DS/ISE/sysgen/hdl/xldelay.v',
  };
  push(@$results, &SgDeliverFile::saveCollaborationInfo($instrs));
  $instrs = {
    'entity_declaration_hash' => '13221af237cea944e0165e8e83b5b740',
    'sourceFile' => 'hdl/xlmcode.v',
    'templateKeyValues' => {
      'crippled_module' => '(
  input [(1 - 1):0] in0,
  input [(1 - 1):0] in1,
  input [(1 - 1):0] in2,
  input [(1 - 1):0] in3,
  input [(1 - 1):0] in4,
  input [(1 - 1):0] in5,
  input [(1 - 1):0] in6,
  input [(1 - 1):0] in7,
  input [(1 - 1):0] in8,
  input [(1 - 1):0] in9,
  input [(1 - 1):0] in10,
  input [(1 - 1):0] in11,
  input [(1 - 1):0] in12,
  input [(1 - 1):0] in13,
  input [(1 - 1):0] in14,
  input [(1 - 1):0] in15,
  input [(1 - 1):0] in16,
  input [(1 - 1):0] in17,
  input [(1 - 1):0] in18,
  input [(1 - 1):0] in19,
  input [(1 - 1):0] in20,
  input [(1 - 1):0] in21,
  input [(1 - 1):0] in22,
  input [(1 - 1):0] in23,
  input [(1 - 1):0] in24,
  input [(1 - 1):0] in25,
  input [(1 - 1):0] in26,
  input [(1 - 1):0] in27,
  input [(1 - 1):0] in28,
  input [(1 - 1):0] in29,
  input [(1 - 1):0] in30,
  output [(31 - 1):0] y,
  input clk,
  input ce,
  input clr);
  wire [(1 - 1):0] in0_1_23;
  wire [(1 - 1):0] in1_1_27;
  wire [(1 - 1):0] in2_1_31;
  wire [(1 - 1):0] in3_1_35;
  wire [(1 - 1):0] in4_1_39;
  wire [(1 - 1):0] in5_1_43;
  wire [(1 - 1):0] in6_1_47;
  wire [(1 - 1):0] in7_1_51;
  wire [(1 - 1):0] in8_1_55;
  wire [(1 - 1):0] in9_1_59;
  wire [(1 - 1):0] in10_1_63;
  wire [(1 - 1):0] in11_1_68;
  wire [(1 - 1):0] in12_1_73;
  wire [(1 - 1):0] in13_1_78;
  wire [(1 - 1):0] in14_1_83;
  wire [(1 - 1):0] in15_1_88;
  wire [(1 - 1):0] in16_1_93;
  wire [(1 - 1):0] in17_1_98;
  wire [(1 - 1):0] in18_1_103;
  wire [(1 - 1):0] in19_1_108;
  wire [(1 - 1):0] in20_1_113;
  wire [(1 - 1):0] in21_1_118;
  wire [(1 - 1):0] in22_1_123;
  wire [(1 - 1):0] in23_1_128;
  wire [(1 - 1):0] in24_1_133;
  wire [(1 - 1):0] in25_1_138;
  wire [(1 - 1):0] in26_1_143;
  wire [(1 - 1):0] in27_1_148;
  wire [(1 - 1):0] in28_1_153;
  wire [(1 - 1):0] in29_1_158;
  wire [(1 - 1):0] in30_1_163;
  wire [(31 - 1):0] y_2_1_concat;
  assign in0_1_23 = in0;
  assign in1_1_27 = in1;
  assign in2_1_31 = in2;
  assign in3_1_35 = in3;
  assign in4_1_39 = in4;
  assign in5_1_43 = in5;
  assign in6_1_47 = in6;
  assign in7_1_51 = in7;
  assign in8_1_55 = in8;
  assign in9_1_59 = in9;
  assign in10_1_63 = in10;
  assign in11_1_68 = in11;
  assign in12_1_73 = in12;
  assign in13_1_78 = in13;
  assign in14_1_83 = in14;
  assign in15_1_88 = in15;
  assign in16_1_93 = in16;
  assign in17_1_98 = in17;
  assign in18_1_103 = in18;
  assign in19_1_108 = in19;
  assign in20_1_113 = in20;
  assign in21_1_118 = in21;
  assign in22_1_123 = in22;
  assign in23_1_128 = in23;
  assign in24_1_133 = in24;
  assign in25_1_138 = in25;
  assign in26_1_143 = in26;
  assign in27_1_148 = in27;
  assign in28_1_153 = in28;
  assign in29_1_158 = in29;
  assign in30_1_163 = in30;
  assign y_2_1_concat = {in0_1_23, in1_1_27, in2_1_31, in3_1_35, in4_1_39, in5_1_43, in6_1_47, in7_1_51, in8_1_55, in9_1_59, in10_1_63, in11_1_68, in12_1_73, in13_1_78, in14_1_83, in15_1_88, in16_1_93, in17_1_98, in18_1_103, in19_1_108, in20_1_113, in21_1_118, in22_1_123, in23_1_128, in24_1_133, in25_1_138, in26_1_143, in27_1_148, in28_1_153, in29_1_158, in30_1_163};
  assign y = y_2_1_concat;
endmodule
',
      'entity_name' => 'concat_36431e6a1e',
    },
  };
  push(@$results, &SgDeliverFile::deliverFile($instrs));
  $instrs = [
    'SELECT Adder_Subtracter spartan3 Xilinx,_Inc. 11.0',
    '# 12.2',
    '# DEVICE spartan3',
    'CSET AINIT_Value = 0',
    'CSET A_Type = Signed',
    'CSET A_Width = 7',
    'CSET Add_Mode = Subtract',
    'CSET B_Constant = false',
    'CSET B_Type = Signed',
    'CSET B_Value = 0',
    'CSET B_Width = 7',
    'CSET Borrow_Sense = Active_Low',
    'CSET Bypass = false',
    'CSET Bypass_CE_Priority = Bypass_Overrides_CE',
    'CSET Bypass_Sense = Active_Low',
    'CSET CE = false',
    'CSET C_In = false',
    'CSET C_Out = false',
    'CSET Implementation = Fabric',
    'CSET Latency = 0',
    'CSET Out_Width = 7',
    'CSET SCLR = false',
    'CSET SINIT = false',
    'CSET SINIT_Value = 0',
    'CSET SSET = false',
    'CSET Sync_CE_Priority = Sync_Overrides_CE',
    'CSET Sync_Ctrl_Priority = Reset_Overrides_Set',
    'SET simulationfiles = Structural',
    'CSET component_name = addsb_11_0_74a2ef4ad86ef6ab',
    'GENERATE',
  ];
  push(@$results, &SgGenerateCores::saveXcoSequence($instrs));
  $instrs = {
    'entity_declaration_hash' => '7c64f93975ae774912004baa71e53a2f',
    'sourceFile' => 'hdl/xladdsub.v',
    'templateKeyValues' => {
      'core_component_def' => '(A, S, B) /* synthesis syn_black_box */;
      input[6:0] A;
     output[6:0] S;
     input[6:0] B;',
      'core_instance_text' => '         .a(full_a),
         .s(core_s),
         .b(full_b)',
      'core_name0' => 'addsb_11_0_74a2ef4ad86ef6ab',
      'entity_name.0' => 'xladdsub',
      'needs_core' => 1,
    },
  };
  push(@$results, &SgDeliverFile::saveCollaborationInfo($instrs));
  $instrs = {
    'entity_declaration_hash' => 'b442c64c974b6cbf5ade9a35e684080d',
    'sourceFile' => 'hdl/xlmcode.v',
    'templateKeyValues' => {
      'crippled_module' => '(
  output [(31 - 1):0] op,
  input clk,
  input ce,
  input clr);
  localparam [(31 - 1):0] const_value = 31\'b1100000011101111010111001101100;
  assign op = 31\'b1100000011101111010111001101100;
endmodule
',
      'entity_name' => 'constant_71b67543d2',
    },
  };
  push(@$results, &SgDeliverFile::deliverFile($instrs));
  $instrs = {
    'entity_declaration_hash' => '176d37b16c7c390a76652c6f57599bf3',
    'sourceFile' => 'hdl/xlmcode.v',
    'templateKeyValues' => {
      'crippled_module' => '(
  output [(5 - 1):0] op,
  input clk,
  input ce,
  input clr);
  localparam [(5 - 1):0] const_value = 5\'b11111;
  assign op = 5\'b11111;
endmodule
',
      'entity_name' => 'constant_ddd853700c',
    },
  };
  push(@$results, &SgDeliverFile::deliverFile($instrs));
  $instrs = {
    'entity_declaration_hash' => '793bb2c2b0c0f1d0adb47b4f8559e37b',
    'sourceFile' => 'hdl/xlmcode.v',
    'templateKeyValues' => {
      'crippled_module' => '(
  input [(31 - 1):0] d0,
  input [(31 - 1):0] d1,
  output [(32 - 1):0] y,
  input clk,
  input ce,
  input clr);
  wire [(31 - 1):0] d0_1_24;
  wire [(31 - 1):0] d1_1_27;
  wire [(31 - 1):0] bit_2_27;
  wire [(31 - 1):0] fully_2_1_bitnot;
  wire [(32 - 1):0] cast_unregy_3_1_convert;
  assign d0_1_24 = d0;
  assign d1_1_27 = d1;
  assign bit_2_27 = d0_1_24 ^ d1_1_27;
  assign fully_2_1_bitnot = ~bit_2_27;
  assign cast_unregy_3_1_convert = {1\'b0, fully_2_1_bitnot[30:0]};
  assign y = cast_unregy_3_1_convert;
endmodule
',
      'entity_name' => 'logical_d2fad2903b',
    },
  };
  push(@$results, &SgDeliverFile::deliverFile($instrs));
  $instrs = {
    'entity_declaration_hash' => 'abe7d88ac1e0a887d185928612012313',
    'sourceFile' => 'hdl/xlmcode.v',
    'templateKeyValues' => {
      'crippled_module' => '(
  input [(6 - 1):0] ip,
  output [(6 - 1):0] op,
  input clk,
  input ce,
  input clr);
  wire [(6 - 1):0] ip_1_23;
  localparam [(6 - 1):0] const_value = 6\'b000000;
  reg [(6 - 1):0] op_mem_46_20[0:(1 - 1)];
  initial
    begin
      op_mem_46_20[0] = 6\'b000000;
    end
  wire [(6 - 1):0] op_mem_46_20_front_din;
  wire [(6 - 1):0] op_mem_46_20_back;
  wire op_mem_46_20_push_front_pop_back_en;
  localparam [(1 - 1):0] const_value_x_000000 = 1\'b1;
  wire [(7 - 1):0] cast_internal_ip_25_3_lsh;
  wire [(6 - 1):0] cast_internal_ip_36_3_convert;
  assign ip_1_23 = ip;
  assign op_mem_46_20_back = op_mem_46_20[0];
  always @(posedge clk)
    begin:proc_op_mem_46_20
      integer i;
      if (((ce == 1\'b1) && (op_mem_46_20_push_front_pop_back_en == 1\'b1)))
        begin
          op_mem_46_20[0] <= op_mem_46_20_front_din;
        end
    end
  assign cast_internal_ip_25_3_lsh = {ip_1_23[5:0], 1\'b0};
  assign cast_internal_ip_36_3_convert = {cast_internal_ip_25_3_lsh[5:0]};
  assign op_mem_46_20_push_front_pop_back_en = 1\'b0;
  assign op = cast_internal_ip_36_3_convert;
endmodule
',
      'entity_name' => 'shift_7887b00bfa',
    },
  };
  push(@$results, &SgDeliverFile::deliverFile($instrs));
  $instrs = {
    'entity_declaration_hash' => '10094de6638fbea859812c638e5520b8',
    'sourceFile' => 'hdl/xlmcode.v',
    'templateKeyValues' => {
      'crippled_module' => '(
  output [(5 - 1):0] op,
  input clk,
  input ce,
  input clr);
  localparam [(5 - 1):0] const_value = 5\'b00000;
  assign op = 5\'b00000;
endmodule
',
      'entity_name' => 'constant_d351c0c7ef',
    },
  };
  push(@$results, &SgDeliverFile::deliverFile($instrs));
  $instrs = {
    'entity_declaration_hash' => '585782eb269a5208b4d1d9a4fd59bee3',
    'sourceFile' => 'hdl/xlmcode.v',
    'templateKeyValues' => {
      'crippled_module' => '(
  output [(5 - 1):0] op,
  input clk,
  input ce,
  input clr);
  localparam [(5 - 1):0] const_value = 5\'b01000;
  assign op = 5\'b01000;
endmodule
',
      'entity_name' => 'constant_c9f00813d5',
    },
  };
  push(@$results, &SgDeliverFile::deliverFile($instrs));
  $instrs = {
    'entity_declaration_hash' => '9a661c195ed5d6fe4e38720d88f58017',
    'sourceFile' => 'hdl/xlmcode.v',
    'templateKeyValues' => {
      'crippled_module' => '(
  input [(1 - 1):0] in0,
  input [(1 - 1):0] in1,
  output [(2 - 1):0] y,
  input clk,
  input ce,
  input clr);
  wire in0_1_23;
  wire in1_1_27;
  wire [(2 - 1):0] y_2_1_concat;
  assign in0_1_23 = in0;
  assign in1_1_27 = in1;
  assign y_2_1_concat = {in0_1_23, in1_1_27};
  assign y = y_2_1_concat;
endmodule
',
      'entity_name' => 'concat_983f7013a1',
    },
  };
  push(@$results, &SgDeliverFile::deliverFile($instrs));
  $instrs = {
    'entity_declaration_hash' => '6ead5a4e6ed771de3490fc719bc11f87',
    'sourceFile' => 'hdl/xlmcode.v',
    'templateKeyValues' => {
      'crippled_module' => '(
  output [(5 - 1):0] op,
  input clk,
  input ce,
  input clr);
  localparam [(5 - 1):0] const_value = 5\'b10000;
  assign op = 5\'b10000;
endmodule
',
      'entity_name' => 'constant_d42a6d7e0e',
    },
  };
  push(@$results, &SgDeliverFile::deliverFile($instrs));
  $instrs = {
    'entity_declaration_hash' => '38f9aad37a335f535bb99f50cf784184',
    'sourceFile' => 'hdl/xlmcode.v',
    'templateKeyValues' => {
      'crippled_module' => '(
  input [(2 - 1):0] sel,
  input [(5 - 1):0] d0,
  input [(5 - 1):0] d1,
  input [(5 - 1):0] d2,
  input [(5 - 1):0] d3,
  input [(1 - 1):0] en,
  output [(5 - 1):0] y,
  input clk,
  input ce,
  input clr);
  wire [(2 - 1):0] sel_1_20;
  wire [(5 - 1):0] d0_1_24;
  wire [(5 - 1):0] d1_1_27;
  wire [(5 - 1):0] d2_1_30;
  wire [(5 - 1):0] d3_1_33;
  wire en_1_36;
  localparam [(5 - 1):0] const_value = 5\'b00000;
  reg [(5 - 1):0] pipe_20_22[0:(1 - 1)];
  initial
    begin
      pipe_20_22[0] = 5\'b00000;
    end
  wire [(5 - 1):0] pipe_20_22_front_din;
  wire [(5 - 1):0] pipe_20_22_back;
  wire pipe_20_22_push_front_pop_back_en;
  reg [(5 - 1):0] unregy_join_6_1;
  reg [(5 - 1):0] pipe_shift_join_22_5;
  reg pipe_shift_join_22_5_en;
  assign sel_1_20 = sel;
  assign d0_1_24 = d0;
  assign d1_1_27 = d1;
  assign d2_1_30 = d2;
  assign d3_1_33 = d3;
  assign en_1_36 = en;
  assign pipe_20_22_back = pipe_20_22[0];
  always @(posedge clk)
    begin:proc_pipe_20_22
      integer i;
      if (((ce == 1\'b1) && (pipe_20_22_push_front_pop_back_en == 1\'b1)))
        begin
          pipe_20_22[0] <= pipe_20_22_front_din;
        end
    end
  always @(d0_1_24 or d1_1_27 or d2_1_30 or d3_1_33 or sel_1_20)
    begin:proc_switch_6_1
      case (sel_1_20)
        2\'b00 :
          begin
            unregy_join_6_1 = d0_1_24;
          end
        2\'b01 :
          begin
            unregy_join_6_1 = d1_1_27;
          end
        2\'b10 :
          begin
            unregy_join_6_1 = d2_1_30;
          end
        default:
          begin
            unregy_join_6_1 = d3_1_33;
          end
      endcase
    end
  always @(en_1_36 or unregy_join_6_1)
    begin:proc_if_22_5
      if (en_1_36)
        begin
          pipe_shift_join_22_5_en = 1\'b1;
        end
      else 
        begin
          pipe_shift_join_22_5_en = 1\'b0;
        end
      pipe_shift_join_22_5 = unregy_join_6_1;
    end
  assign pipe_20_22_front_din = pipe_shift_join_22_5;
  assign pipe_20_22_push_front_pop_back_en = pipe_shift_join_22_5_en;
  assign y = pipe_20_22_back;
endmodule
',
      'entity_name' => 'mux_c6437f97ac',
    },
  };
  push(@$results, &SgDeliverFile::deliverFile($instrs));
  $instrs = {
    'entity_declaration_hash' => 'a5de7ab5d3f1a7feb26ac17a628621b8',
    'sourceFile' => 'hdl/xlmcode.v',
    'templateKeyValues' => {
      'crippled_module' => '(
  input [(5 - 1):0] ip,
  output [(6 - 1):0] op,
  input clk,
  input ce,
  input clr);
  wire [(5 - 1):0] ip_18_25;
  localparam signed [(6 - 1):0] const_value = 6\'sb000000;
  reg signed [(6 - 1):0] op_mem_42_20[0:(1 - 1)];
  initial
    begin
      op_mem_42_20[0] = 6\'b000000;
    end
  wire signed [(6 - 1):0] op_mem_42_20_front_din;
  wire signed [(6 - 1):0] op_mem_42_20_back;
  wire op_mem_42_20_push_front_pop_back_en;
  localparam [(1 - 1):0] const_value_x_000000 = 1\'b1;
  wire signed [(6 - 1):0] cast_30_16;
  wire signed [(6 - 1):0] internal_ip_30_1_neg;
  assign ip_18_25 = ip;
  assign op_mem_42_20_back = op_mem_42_20[0];
  always @(posedge clk)
    begin:proc_op_mem_42_20
      integer i;
      if (((ce == 1\'b1) && (op_mem_42_20_push_front_pop_back_en == 1\'b1)))
        begin
          op_mem_42_20[0] <= op_mem_42_20_front_din;
        end
    end
  assign cast_30_16 = {1\'b0, ip_18_25[4:0]};
  assign internal_ip_30_1_neg = -cast_30_16;
  assign op_mem_42_20_push_front_pop_back_en = 1\'b0;
  assign op = internal_ip_30_1_neg;
endmodule
',
      'entity_name' => 'negate_9e62559a8c',
    },
  };
  push(@$results, &SgDeliverFile::deliverFile($instrs));
  $instrs = {
    'entity_declaration_hash' => 'fbfcb9f1b7065d612965a8bae2f7ca6c',
    'sourceFile' => 'hdl/xlmcode.v',
    'templateKeyValues' => {
      'crippled_module' => '(
  input [(7 - 1):0] a,
  input [(5 - 1):0] b,
  output [(1 - 1):0] op,
  input clk,
  input ce,
  input clr);
  wire signed [(7 - 1):0] a_1_31;
  wire [(5 - 1):0] b_1_34;
  localparam [(1 - 1):0] const_value = 1\'b1;
  wire signed [(7 - 1):0] cast_18_16;
  wire result_18_3_rel;
  assign a_1_31 = a;
  assign b_1_34 = b;
  assign cast_18_16 = {2\'b00, b_1_34[4:0]};
  assign result_18_3_rel = a_1_31 > cast_18_16;
  assign op = result_18_3_rel;
endmodule
',
      'entity_name' => 'relational_9d3b17b3e4',
    },
  };
  push(@$results, &SgDeliverFile::deliverFile($instrs));
  $instrs = {
    'entity_declaration_hash' => '96516ed39d03b8c538aae9c0781f3009',
    'sourceFile' => 'hdl/xlmcode.v',
    'templateKeyValues' => {
      'crippled_module' => '(
  input [(7 - 1):0] a,
  input [(6 - 1):0] b,
  output [(1 - 1):0] op,
  input clk,
  input ce,
  input clr);
  wire signed [(7 - 1):0] a_1_31;
  wire signed [(6 - 1):0] b_1_34;
  localparam [(1 - 1):0] const_value = 1\'b1;
  wire signed [(7 - 1):0] cast_16_16;
  wire result_16_3_rel;
  assign a_1_31 = a;
  assign b_1_34 = b;
  assign cast_16_16 = {{1{b_1_34[5]}}, b_1_34[5:0]};
  assign result_16_3_rel = a_1_31 < cast_16_16;
  assign op = result_16_3_rel;
endmodule
',
      'entity_name' => 'relational_ead40b1d08',
    },
  };
  push(@$results, &SgDeliverFile::deliverFile($instrs));
  $instrs = {
    'entity_declaration_hash' => '33335ae1137bfa46aaceab77ca2607c1',
    'sourceFile' => 'hdl/xlmcode.v',
    'templateKeyValues' => {
      'crippled_module' => '(
  output [(31 - 1):0] op,
  input clk,
  input ce,
  input clr);
  localparam [(31 - 1):0] const_value = 31\'b1001110000001110111101011100110;
  assign op = 31\'b1001110000001110111101011100110;
endmodule
',
      'entity_name' => 'constant_881c4822c4',
    },
  };
  push(@$results, &SgDeliverFile::deliverFile($instrs));
  $instrs = {
    'entity_declaration_hash' => '7049542a81d5c15e2825507eefe396c4',
    'sourceFile' => 'hdl/xlmcode.v',
    'templateKeyValues' => {
      'crippled_module' => '(
  output [(5 - 1):0] op,
  input clk,
  input ce,
  input clr);
  localparam [(5 - 1):0] const_value = 5\'b00001;
  assign op = 5\'b00001;
endmodule
',
      'entity_name' => 'constant_842cb26778',
    },
  };
  push(@$results, &SgDeliverFile::deliverFile($instrs));
  $instrs = {
    'entity_declaration_hash' => 'e48dd851ee2e36e5e4b53a3427dcec88',
    'sourceFile' => 'hdl/xlmcode.v',
    'templateKeyValues' => {
      'crippled_module' => '(
  output [(5 - 1):0] op,
  input clk,
  input ce,
  input clr);
  localparam [(5 - 1):0] const_value = 5\'b01001;
  assign op = 5\'b01001;
endmodule
',
      'entity_name' => 'constant_496a91add6',
    },
  };
  push(@$results, &SgDeliverFile::deliverFile($instrs));
  $instrs = {
    'entity_declaration_hash' => 'a9268ec7c53a70766da5c44d2b21a647',
    'sourceFile' => 'hdl/xlmcode.v',
    'templateKeyValues' => {
      'crippled_module' => '(
  output [(31 - 1):0] op,
  input clk,
  input ce,
  input clr);
  localparam [(31 - 1):0] const_value = 31\'b1101100111000000111011110101110;
  assign op = 31\'b1101100111000000111011110101110;
endmodule
',
      'entity_name' => 'constant_8cbbc2386c',
    },
  };
  push(@$results, &SgDeliverFile::deliverFile($instrs));
  $instrs = {
    'entity_declaration_hash' => 'f3bef3f130a2b936d02a53693a4609e7',
    'sourceFile' => 'hdl/xlmcode.v',
    'templateKeyValues' => {
      'crippled_module' => '(
  output [(5 - 1):0] op,
  input clk,
  input ce,
  input clr);
  localparam [(5 - 1):0] const_value = 5\'b01010;
  assign op = 5\'b01010;
endmodule
',
      'entity_name' => 'constant_9d6f0730aa',
    },
  };
  push(@$results, &SgDeliverFile::deliverFile($instrs));
  $instrs = {
    'entity_declaration_hash' => '2c3de15e0fbc7b476b71d022819c2c0c',
    'sourceFile' => 'hdl/xlmcode.v',
    'templateKeyValues' => {
      'crippled_module' => '(
  output [(5 - 1):0] op,
  input clk,
  input ce,
  input clr);
  localparam [(5 - 1):0] const_value = 5\'b00010;
  assign op = 5\'b00010;
endmodule
',
      'entity_name' => 'constant_6873b4d6fb',
    },
  };
  push(@$results, &SgDeliverFile::deliverFile($instrs));
  $instrs = {
    'entity_declaration_hash' => '821796d2c6897736cf565b970ce3f2f2',
    'sourceFile' => 'hdl/xlmcode.v',
    'templateKeyValues' => {
      'crippled_module' => '(
  output [(31 - 1):0] op,
  input clk,
  input ce,
  input clr);
  localparam [(31 - 1):0] const_value = 31\'b1100110110011100000011101111010;
  assign op = 31\'b1100110110011100000011101111010;
endmodule
',
      'entity_name' => 'constant_0936470fae',
    },
  };
  push(@$results, &SgDeliverFile::deliverFile($instrs));
  $instrs = {
    'entity_declaration_hash' => '321f2cf113be55316e36cc0eacdb736f',
    'sourceFile' => 'hdl/xlmcode.v',
    'templateKeyValues' => {
      'crippled_module' => '(
  output [(5 - 1):0] op,
  input clk,
  input ce,
  input clr);
  localparam [(5 - 1):0] const_value = 5\'b00011;
  assign op = 5\'b00011;
endmodule
',
      'entity_name' => 'constant_21697d73c9',
    },
  };
  push(@$results, &SgDeliverFile::deliverFile($instrs));
  $instrs = {
    'entity_declaration_hash' => 'a959c8d688c9f8ecde641081b8be1034',
    'sourceFile' => 'hdl/xlmcode.v',
    'templateKeyValues' => {
      'crippled_module' => '(
  output [(5 - 1):0] op,
  input clk,
  input ce,
  input clr);
  localparam [(5 - 1):0] const_value = 5\'b01011;
  assign op = 5\'b01011;
endmodule
',
      'entity_name' => 'constant_d28c6918d5',
    },
  };
  push(@$results, &SgDeliverFile::deliverFile($instrs));
  $instrs = {
    'entity_declaration_hash' => 'ad822de49212cabb4405473e54d71fbf',
    'sourceFile' => 'hdl/xlmcode.v',
    'templateKeyValues' => {
      'crippled_module' => '(
  output [(31 - 1):0] op,
  input clk,
  input ce,
  input clr);
  localparam [(31 - 1):0] const_value = 31\'b0101110011011001110000001110111;
  assign op = 31\'b0101110011011001110000001110111;
endmodule
',
      'entity_name' => 'constant_b7309cb9e2',
    },
  };
  push(@$results, &SgDeliverFile::deliverFile($instrs));
  $instrs = {
    'entity_declaration_hash' => 'ce86cafcebabf2fcfa3f73b059884d3e',
    'sourceFile' => 'hdl/xlmcode.v',
    'templateKeyValues' => {
      'crippled_module' => '(
  output [(5 - 1):0] op,
  input clk,
  input ce,
  input clr);
  localparam [(5 - 1):0] const_value = 5\'b00100;
  assign op = 5\'b00100;
endmodule
',
      'entity_name' => 'constant_5d205e60f8',
    },
  };
  push(@$results, &SgDeliverFile::deliverFile($instrs));
  $instrs = {
    'entity_declaration_hash' => 'bdae0603800cd31a83b31d88c7e32aa1',
    'sourceFile' => 'hdl/xlmcode.v',
    'templateKeyValues' => {
      'crippled_module' => '(
  output [(5 - 1):0] op,
  input clk,
  input ce,
  input clr);
  localparam [(5 - 1):0] const_value = 5\'b01100;
  assign op = 5\'b01100;
endmodule
',
      'entity_name' => 'constant_4ae9d2aff2',
    },
  };
  push(@$results, &SgDeliverFile::deliverFile($instrs));
  $instrs = {
    'entity_declaration_hash' => 'ebdd5f0fd2b4f6d80c9e56ecea20354e',
    'sourceFile' => 'hdl/xlmcode.v',
    'templateKeyValues' => {
      'crippled_module' => '(
  output [(31 - 1):0] op,
  input clk,
  input ce,
  input clr);
  localparam [(31 - 1):0] const_value = 31\'b1111010111001101100111000000111;
  assign op = 31\'b1111010111001101100111000000111;
endmodule
',
      'entity_name' => 'constant_b99e9dc088',
    },
  };
  push(@$results, &SgDeliverFile::deliverFile($instrs));
  $instrs = {
    'entity_declaration_hash' => '930eace3ea5facd2766faff2506e9f64',
    'sourceFile' => 'hdl/xlmcode.v',
    'templateKeyValues' => {
      'crippled_module' => '(
  output [(5 - 1):0] op,
  input clk,
  input ce,
  input clr);
  localparam [(5 - 1):0] const_value = 5\'b00101;
  assign op = 5\'b00101;
endmodule
',
      'entity_name' => 'constant_c602ca122d',
    },
  };
  push(@$results, &SgDeliverFile::deliverFile($instrs));
  $instrs = {
    'entity_declaration_hash' => 'd8cadcbc03790589cfbc961a92dc3916',
    'sourceFile' => 'hdl/xlmcode.v',
    'templateKeyValues' => {
      'crippled_module' => '(
  output [(5 - 1):0] op,
  input clk,
  input ce,
  input clr);
  localparam [(5 - 1):0] const_value = 5\'b01101;
  assign op = 5\'b01101;
endmodule
',
      'entity_name' => 'constant_c9e57c44e3',
    },
  };
  push(@$results, &SgDeliverFile::deliverFile($instrs));
  $instrs = {
    'entity_declaration_hash' => '98209d3e63eea02b2eeedfcfb838037f',
    'sourceFile' => 'hdl/xlmcode.v',
    'templateKeyValues' => {
      'crippled_module' => '(
  output [(31 - 1):0] op,
  input clk,
  input ce,
  input clr);
  localparam [(31 - 1):0] const_value = 31\'b1110111101011100110110011100000;
  assign op = 31\'b1110111101011100110110011100000;
endmodule
',
      'entity_name' => 'constant_8167e6d8d4',
    },
  };
  push(@$results, &SgDeliverFile::deliverFile($instrs));
  $instrs = {
    'entity_declaration_hash' => 'bf9be7f4468289f1a031f490fb8d0845',
    'sourceFile' => 'hdl/xlmcode.v',
    'templateKeyValues' => {
      'crippled_module' => '(
  output [(5 - 1):0] op,
  input clk,
  input ce,
  input clr);
  localparam [(5 - 1):0] const_value = 5\'b00110;
  assign op = 5\'b00110;
endmodule
',
      'entity_name' => 'constant_6f0bdcb683',
    },
  };
  push(@$results, &SgDeliverFile::deliverFile($instrs));
  $instrs = {
    'entity_declaration_hash' => '722a0ecb53d597922f88b2ca59b2b5b4',
    'sourceFile' => 'hdl/xlmcode.v',
    'templateKeyValues' => {
      'crippled_module' => '(
  output [(5 - 1):0] op,
  input clk,
  input ce,
  input clr);
  localparam [(5 - 1):0] const_value = 5\'b01110;
  assign op = 5\'b01110;
endmodule
',
      'entity_name' => 'constant_cfb8d50ad3',
    },
  };
  push(@$results, &SgDeliverFile::deliverFile($instrs));
  $instrs = {
    'entity_declaration_hash' => '514ec29ce4fa53b406a7086a0b34ac1b',
    'sourceFile' => 'hdl/xlmcode.v',
    'templateKeyValues' => {
      'crippled_module' => '(
  output [(31 - 1):0] op,
  input clk,
  input ce,
  input clr);
  localparam [(31 - 1):0] const_value = 31\'b0000111011110101110011011001110;
  assign op = 31\'b0000111011110101110011011001110;
endmodule
',
      'entity_name' => 'constant_6f83520114',
    },
  };
  push(@$results, &SgDeliverFile::deliverFile($instrs));
  $instrs = {
    'entity_declaration_hash' => '061c863a35c3563a762bec418244bb12',
    'sourceFile' => 'hdl/xlmcode.v',
    'templateKeyValues' => {
      'crippled_module' => '(
  output [(5 - 1):0] op,
  input clk,
  input ce,
  input clr);
  localparam [(5 - 1):0] const_value = 5\'b00111;
  assign op = 5\'b00111;
endmodule
',
      'entity_name' => 'constant_21c713eea3',
    },
  };
  push(@$results, &SgDeliverFile::deliverFile($instrs));
  $instrs = {
    'entity_declaration_hash' => '8b46b956846be8f358d56399801ef605',
    'sourceFile' => 'hdl/xlmcode.v',
    'templateKeyValues' => {
      'crippled_module' => '(
  output [(5 - 1):0] op,
  input clk,
  input ce,
  input clr);
  localparam [(5 - 1):0] const_value = 5\'b01111;
  assign op = 5\'b01111;
endmodule
',
      'entity_name' => 'constant_9f20215276',
    },
  };
  push(@$results, &SgDeliverFile::deliverFile($instrs));
  $instrs = {
    'entity_declaration_hash' => '8b1d8cd5194d94ece6d97db650676041',
    'sourceFile' => 'C:/Xilinx/12.2/ISE_DS/ISE/sysgen/hdl/xldsamp.v',
  };
  push(@$results, &SgDeliverFile::saveCollaborationInfo($instrs));
  $instrs = {
    'entity_declaration_hash' => '529c55df87231335b431fd154df08fe8',
    'sourceFile' => 'hdl/xlmcode.v',
    'templateKeyValues' => {
      'crippled_module' => '(
  input [(5 - 1):0] d0,
  input [(5 - 1):0] d1,
  input [(5 - 1):0] d2,
  input [(5 - 1):0] d3,
  input [(5 - 1):0] d4,
  input [(5 - 1):0] d5,
  input [(5 - 1):0] d6,
  input [(5 - 1):0] d7,
  output [(5 - 1):0] y,
  input clk,
  input ce,
  input clr);
  wire [(5 - 1):0] d0_1_24;
  wire [(5 - 1):0] d1_1_27;
  wire [(5 - 1):0] d2_1_30;
  wire [(5 - 1):0] d3_1_33;
  wire [(5 - 1):0] d4_1_36;
  wire [(5 - 1):0] d5_1_39;
  wire [(5 - 1):0] d6_1_42;
  wire [(5 - 1):0] d7_1_45;
  wire [(5 - 1):0] fully_2_1_bit;
  assign d0_1_24 = d0;
  assign d1_1_27 = d1;
  assign d2_1_30 = d2;
  assign d3_1_33 = d3;
  assign d4_1_36 = d4;
  assign d5_1_39 = d5;
  assign d6_1_42 = d6;
  assign d7_1_45 = d7;
  assign fully_2_1_bit = d0_1_24 | d1_1_27 | d2_1_30 | d3_1_33 | d4_1_36 | d5_1_39 | d6_1_42 | d7_1_45;
  assign y = fully_2_1_bit;
endmodule
',
      'entity_name' => 'logical_5ab067d51e',
    },
  };
  push(@$results, &SgDeliverFile::deliverFile($instrs));
  $instrs = {
    'entity_declaration_hash' => '7ae2ccdac4696659b8791bc697281d14',
    'sourceFile' => 'C:/Xilinx/12.2/ISE_DS/ISE/sysgen/hdl/xlslice.v',
  };
  push(@$results, &SgDeliverFile::saveCollaborationInfo($instrs));
  $instrs = {
    'entity_declaration_hash' => 'd357bddd26397332b586ce7578a41128',
    'sourceFile' => 'hdl/xlmcode.v',
    'templateKeyValues' => {
      'crippled_module' => '(
  output [(1 - 1):0] op,
  input clk,
  input ce,
  input clr);
  localparam [(1 - 1):0] const_value = 1\'b0;
  assign op = 1\'b0;
endmodule
',
      'entity_name' => 'constant_096f76a5fd',
    },
  };
  push(@$results, &SgDeliverFile::deliverFile($instrs));
  $instrs = {
    'entity_declaration_hash' => 'f6422b242e10078f0ad80b020933cb23',
    'sourceFile' => 'C:/Xilinx/12.2/ISE_DS/ISE/sysgen/hdl/xldelay.v',
  };
  push(@$results, &SgDeliverFile::saveCollaborationInfo($instrs));
  $instrs = {
    'entity_declaration_hash' => 'eb0c6cb740a7e975fa480f41d34e74d9',
    'sourceFile' => 'hdl/xlmcode.v',
    'templateKeyValues' => {
      'crippled_module' => '(
  input [(1 - 1):0] d0,
  input [(1 - 1):0] d1,
  input [(1 - 1):0] d2,
  input [(1 - 1):0] d3,
  output [(1 - 1):0] y,
  input clk,
  input ce,
  input clr);
  wire d0_1_24;
  wire d1_1_27;
  wire d2_1_30;
  wire d3_1_33;
  wire fully_2_1_bit;
  assign d0_1_24 = d0;
  assign d1_1_27 = d1;
  assign d2_1_30 = d2;
  assign d3_1_33 = d3;
  assign fully_2_1_bit = d0_1_24 & d1_1_27 & d2_1_30 & d3_1_33;
  assign y = fully_2_1_bit;
endmodule
',
      'entity_name' => 'logical_818bd6d54b',
    },
  };
  push(@$results, &SgDeliverFile::deliverFile($instrs));
  $instrs = {
    'entity_declaration_hash' => '2c970ece40fb1dbc42063da69c3a8b6a',
    'sourceFile' => 'hdl/xlmcode.v',
    'templateKeyValues' => {
      'crippled_module' => '(
  input [(1 - 1):0] d0,
  input [(1 - 1):0] d1,
  output [(1 - 1):0] y,
  input clk,
  input ce,
  input clr);
  wire d0_1_24;
  wire d1_1_27;
  wire fully_2_1_bit;
  assign d0_1_24 = d0;
  assign d1_1_27 = d1;
  assign fully_2_1_bit = d0_1_24 | d1_1_27;
  assign y = fully_2_1_bit;
endmodule
',
      'entity_name' => 'logical_7970a672aa',
    },
  };
  push(@$results, &SgDeliverFile::deliverFile($instrs));
  $instrs = [
    'SELECT Binary_Counter spartan3 Xilinx,_Inc. 11.0',
    '# 12.2',
    '# DEVICE spartan3',
    'CSET ainit_value = 0',
    'CSET ce = true',
    'CSET count_mode = DOWN',
    'CSET fb_latency = 0',
    'CSET final_count_value = 1',
    'CSET implementation = Fabric',
    'CSET increment_value = 1',
    'CSET latency = 1',
    'CSET load = true',
    'CSET output_width = 8',
    'CSET restrict_count = false',
    'CSET sclr = false',
    'CSET sinit = true',
    'CSET sinit_value = 0',
    'CSET sset = false',
    'CSET sync_ce_priority = Sync_Overrides_CE',
    'CSET sync_threshold_output = false',
    'CSET syncctrlpriority = Reset_Overrides_Set',
    'CSET component_name = cntr_11_0_5d986fed0493f6d2',
    'GENERATE',
  ];
  push(@$results, &SgGenerateCores::saveXcoSequence($instrs));
  $instrs = {
    'entity_declaration_hash' => '79a12d2894fc2c62b5e11cd2d3cb1611',
    'sourceFile' => 'hdl/xlcounter_free.v',
    'templateKeyValues' => {
      'core_instance_text' => '        .clk(clk),
        .ce(core_ce),
        .sinit(core_sinit),
        .load(load),
        .l(din),
        .q(op_net)',
      'core_name0' => 'cntr_11_0_5d986fed0493f6d2',
      'entity_name.0' => 'xlcounter_free',
      'needs_core' => 1,
    },
  };
  push(@$results, &SgDeliverFile::saveCollaborationInfo($instrs));
  $instrs = [
    'SELECT Binary_Counter spartan3 Xilinx,_Inc. 11.0',
    '# 12.2',
    '# DEVICE spartan3',
    'CSET ainit_value = 0',
    'CSET ce = true',
    'CSET count_mode = UP',
    'CSET fb_latency = 0',
    'CSET final_count_value = 1',
    'CSET implementation = Fabric',
    'CSET increment_value = 1',
    'CSET latency = 1',
    'CSET load = false',
    'CSET output_width = 8',
    'CSET restrict_count = false',
    'CSET sclr = false',
    'CSET sinit = true',
    'CSET sinit_value = 0',
    'CSET sset = false',
    'CSET sync_ce_priority = Sync_Overrides_CE',
    'CSET sync_threshold_output = false',
    'CSET syncctrlpriority = Reset_Overrides_Set',
    'CSET component_name = cntr_11_0_381744e1859ad0c1',
    'GENERATE',
  ];
  push(@$results, &SgGenerateCores::saveXcoSequence($instrs));
  $instrs = {
    'entity_declaration_hash' => '0b96e708415907eb8258cf52ada8fc6d',
    'sourceFile' => 'hdl/xlcounter_free.v',
    'templateKeyValues' => {
      'core_instance_text' => '        .clk(clk),
        .ce(core_ce),
        .sinit(core_sinit),
        .q(op_net)',
      'core_name0' => 'cntr_11_0_381744e1859ad0c1',
      'entity_name.0' => 'xlcounter_free',
      'needs_core' => 1,
    },
  };
  push(@$results, &SgDeliverFile::saveCollaborationInfo($instrs));
  $instrs = {
    'entity_declaration_hash' => '03d39089b5154b5088e985635b5c72e6',
    'sourceFile' => 'hdl/xlmcode.v',
    'templateKeyValues' => {
      'crippled_module' => '(
  input [(1 - 1):0] a,
  input [(8 - 1):0] b,
  output [(1 - 1):0] op,
  input clk,
  input ce,
  input clr);
  wire [(1 - 1):0] a_1_31;
  wire [(8 - 1):0] b_1_34;
  localparam [(1 - 1):0] const_value = 1\'b1;
  wire [(8 - 1):0] cast_14_12;
  wire result_14_3_rel;
  assign a_1_31 = a;
  assign b_1_34 = b;
  assign cast_14_12 = {7\'b0000000, a_1_31};
  assign result_14_3_rel = cast_14_12 != b_1_34;
  assign op = result_14_3_rel;
endmodule
',
      'entity_name' => 'relational_e0420a237d',
    },
  };
  push(@$results, &SgDeliverFile::deliverFile($instrs));
  $instrs = {
    'entity_declaration_hash' => '8a7ec334ace7ee13af4e6b6cb3cba2e7',
    'sourceFile' => 'hdl/xlmcode.v',
    'templateKeyValues' => {
      'crippled_module' => '(
  input [(8 - 1):0] ip,
  output [(8 - 1):0] op,
  input clk,
  input ce,
  input clr);
  wire [(8 - 1):0] ip_1_23;
  localparam [(8 - 1):0] const_value = 8\'b00000000;
  reg [(8 - 1):0] op_mem_46_20[0:(1 - 1)];
  initial
    begin
      op_mem_46_20[0] = 8\'b00000000;
    end
  wire [(8 - 1):0] op_mem_46_20_front_din;
  wire [(8 - 1):0] op_mem_46_20_back;
  wire op_mem_46_20_push_front_pop_back_en;
  localparam [(1 - 1):0] const_value_x_000000 = 1\'b1;
  wire [(9 - 1):0] cast_internal_ip_25_3_lsh;
  wire [(8 - 1):0] cast_internal_ip_33_3_convert;
  assign ip_1_23 = ip;
  assign op_mem_46_20_back = op_mem_46_20[0];
  always @(posedge clk)
    begin:proc_op_mem_46_20
      integer i;
      if (((ce == 1\'b1) && (op_mem_46_20_push_front_pop_back_en == 1\'b1)))
        begin
          op_mem_46_20[0] <= op_mem_46_20_front_din;
        end
    end
  assign cast_internal_ip_25_3_lsh = {ip_1_23[7:0], 1\'b0};
  assign cast_internal_ip_33_3_convert = {cast_internal_ip_25_3_lsh[7:0]};
  assign op_mem_46_20_push_front_pop_back_en = 1\'b0;
  assign op = cast_internal_ip_33_3_convert;
endmodule
',
      'entity_name' => 'shift_e4ef0a64d1',
    },
  };
  push(@$results, &SgDeliverFile::deliverFile($instrs));
  $instrs = {
    'entity_declaration_hash' => 'b87d80e838865ee71b7102b0fddec752',
    'sourceFile' => 'hdl/xlmcode.v',
    'templateKeyValues' => {
      'crippled_module' => '(
  input [(4 - 1):0] in0,
  input [(4 - 1):0] in1,
  output [(8 - 1):0] y,
  input clk,
  input ce,
  input clr);
  wire [(4 - 1):0] in0_1_23;
  wire [(4 - 1):0] in1_1_27;
  wire [(8 - 1):0] y_2_1_concat;
  assign in0_1_23 = in0;
  assign in1_1_27 = in1;
  assign y_2_1_concat = {in0_1_23, in1_1_27};
  assign y = y_2_1_concat;
endmodule
',
      'entity_name' => 'concat_0cb9cb10c3',
    },
  };
  push(@$results, &SgDeliverFile::deliverFile($instrs));
  $instrs = {
    'entity_declaration_hash' => '68f93337138032ce7f4ac8aba5ec9d1f',
    'sourceFile' => 'C:/Xilinx/12.2/ISE_DS/ISE/sysgen/hdl/xldelay.v',
  };
  push(@$results, &SgDeliverFile::saveCollaborationInfo($instrs));
  $instrs = {
    'entity_declaration_hash' => '94215422d21d51ab46de1256568c2c39',
    'sourceFile' => 'C:/Xilinx/12.2/ISE_DS/ISE/sysgen/hdl/xldelay.v',
  };
  push(@$results, &SgDeliverFile::saveCollaborationInfo($instrs));
  $instrs = {
    'entity_declaration_hash' => '2a8418e6c2153f7e2d55ffae0103fece',
    'sourceFile' => 'C:/Xilinx/12.2/ISE_DS/ISE/sysgen/hdl/xldsamp.v',
  };
  push(@$results, &SgDeliverFile::saveCollaborationInfo($instrs));
  $instrs = {
    'entity_declaration_hash' => '8e21e6ddb34943706b7ad380003a5115',
    'sourceFile' => 'hdl/xlmcode.v',
    'templateKeyValues' => {
      'crippled_module' => '(
  input [(1 - 1):0] ip,
  output [(1 - 1):0] op,
  input clk,
  input ce,
  input clr);
  wire ip_1_26;
  reg op_mem_22_20[0:(1 - 1)];
  initial
    begin
      op_mem_22_20[0] = 1\'b0;
    end
  wire op_mem_22_20_front_din;
  wire op_mem_22_20_back;
  wire op_mem_22_20_push_front_pop_back_en;
  localparam [(1 - 1):0] const_value = 1\'b1;
  wire internal_ip_12_1_bitnot;
  assign ip_1_26 = ip;
  assign op_mem_22_20_back = op_mem_22_20[0];
  always @(posedge clk)
    begin:proc_op_mem_22_20
      integer i;
      if (((ce == 1\'b1) && (op_mem_22_20_push_front_pop_back_en == 1\'b1)))
        begin
          op_mem_22_20[0] <= op_mem_22_20_front_din;
        end
    end
  assign internal_ip_12_1_bitnot = ~ip_1_26;
  assign op_mem_22_20_front_din = internal_ip_12_1_bitnot;
  assign op_mem_22_20_push_front_pop_back_en = 1\'b1;
  assign op = op_mem_22_20_back;
endmodule
',
      'entity_name' => 'inverter_c4c732b07f',
    },
  };
  push(@$results, &SgDeliverFile::deliverFile($instrs));
  $instrs = {
    'entity_declaration_hash' => '20c6051bc71489d570d9d9ee37894f99',
    'sourceFile' => 'hdl/xlmcode.v',
    'templateKeyValues' => {
      'crippled_module' => '(
  output [(4 - 1):0] op,
  input clk,
  input ce,
  input clr);
  localparam [(4 - 1):0] const_value = 4\'b0010;
  assign op = 4\'b0010;
endmodule
',
      'entity_name' => 'constant_7224f93510',
    },
  };
  push(@$results, &SgDeliverFile::deliverFile($instrs));
  $instrs = {
    'entity_declaration_hash' => '6cb6665c2ed6b006d82e79667b6cd846',
    'sourceFile' => 'hdl/xlmcode.v',
    'templateKeyValues' => {
      'crippled_module' => '(
  output [(16 - 1):0] op,
  input clk,
  input ce,
  input clr);
  localparam [(16 - 1):0] const_value = 16\'b0000000000000000;
  assign op = 16\'b0000000000000000;
endmodule
',
      'entity_name' => 'constant_dc21c1c385',
    },
  };
  push(@$results, &SgDeliverFile::deliverFile($instrs));
  $instrs = {
    'entity_declaration_hash' => '728d084cf20209be2f681c0eb2bf1fd0',
    'sourceFile' => 'C:/Xilinx/12.2/ISE_DS/ISE/sysgen/hdl/xldelay.v',
  };
  push(@$results, &SgDeliverFile::saveCollaborationInfo($instrs));
  $instrs = {
    'entity_declaration_hash' => '7375ba00c4971b24b95a2f86d24d1046',
    'sourceFile' => 'C:/Xilinx/12.2/ISE_DS/ISE/sysgen/hdl/xldelay.v',
  };
  push(@$results, &SgDeliverFile::saveCollaborationInfo($instrs));
  $instrs = {
    'entity_declaration_hash' => 'b87ab8f772a9470ec60c16051ac4a6c5',
    'sourceFile' => 'hdl/xlmcode.v',
    'templateKeyValues' => {
      'crippled_module' => '(
  input [(1 - 1):0] d0,
  input [(1 - 1):0] d1,
  input [(1 - 1):0] d2,
  output [(1 - 1):0] y,
  input clk,
  input ce,
  input clr);
  wire d0_1_24;
  wire d1_1_27;
  wire d2_1_30;
  wire fully_2_1_bit;
  assign d0_1_24 = d0;
  assign d1_1_27 = d1;
  assign d2_1_30 = d2;
  assign fully_2_1_bit = d0_1_24 & d1_1_27 & d2_1_30;
  assign y = fully_2_1_bit;
endmodule
',
      'entity_name' => 'logical_a950764719',
    },
  };
  push(@$results, &SgDeliverFile::deliverFile($instrs));
  $instrs = {
    'entity_declaration_hash' => 'a09582a4010da019b99726ecfae97d7f',
    'sourceFile' => 'hdl/xlmcode.v',
    'templateKeyValues' => {
      'crippled_module' => '(
  input [(1 - 1):0] sel,
  input [(16 - 1):0] d0,
  input [(16 - 1):0] d1,
  output [(16 - 1):0] y,
  input clk,
  input ce,
  input clr);
  wire sel_1_20;
  wire [(16 - 1):0] d0_1_24;
  wire [(16 - 1):0] d1_1_27;
  wire [(1 - 1):0] sel_internal_2_1_convert;
  reg [(16 - 1):0] unregy_join_6_1;
  assign sel_1_20 = sel;
  assign d0_1_24 = d0;
  assign d1_1_27 = d1;
  assign sel_internal_2_1_convert = {sel_1_20};
  always @(d0_1_24 or d1_1_27 or sel_internal_2_1_convert)
    begin:proc_switch_6_1
      case (sel_internal_2_1_convert)
        1\'b0 :
          begin
            unregy_join_6_1 = d0_1_24;
          end
        default:
          begin
            unregy_join_6_1 = d1_1_27;
          end
      endcase
    end
  assign y = unregy_join_6_1;
endmodule
',
      'entity_name' => 'mux_31d78b046f',
    },
  };
  push(@$results, &SgDeliverFile::deliverFile($instrs));
  $instrs = {
    'entity_declaration_hash' => '66054526a78de7d9090724f30c432200',
    'sourceFile' => 'hdl/xlmcode.v',
    'templateKeyValues' => {
      'crippled_module' => '(
  input [(16 - 1):0] a,
  input [(16 - 1):0] b,
  output [(1 - 1):0] op,
  input clk,
  input ce,
  input clr);
  wire [(16 - 1):0] a_1_31;
  wire [(16 - 1):0] b_1_34;
  localparam [(1 - 1):0] const_value = 1\'b1;
  wire result_18_3_rel;
  assign a_1_31 = a;
  assign b_1_34 = b;
  assign result_18_3_rel = a_1_31 > b_1_34;
  assign op = result_18_3_rel;
endmodule
',
      'entity_name' => 'relational_a2b8e7c11c',
    },
  };
  push(@$results, &SgDeliverFile::deliverFile($instrs));
  $instrs = {
    'entity_declaration_hash' => '5bbc2b9619b3979a79006823918f5bf8',
    'sourceFile' => 'hdl/xlmcode.v',
    'templateKeyValues' => {
      'crippled_module' => '(
  input [(4 - 1):0] a,
  input [(4 - 1):0] b,
  output [(1 - 1):0] op,
  input clk,
  input ce,
  input clr);
  wire [(4 - 1):0] a_1_31;
  wire [(4 - 1):0] b_1_34;
  localparam [(1 - 1):0] const_value = 1\'b1;
  wire result_12_3_rel;
  assign a_1_31 = a;
  assign b_1_34 = b;
  assign result_12_3_rel = a_1_31 == b_1_34;
  assign op = result_12_3_rel;
endmodule
',
      'entity_name' => 'relational_18eccffee7',
    },
  };
  push(@$results, &SgDeliverFile::deliverFile($instrs));
  $instrs = {
    'entity_declaration_hash' => '98133d924ba65fca38ffe1d506195bd3',
    'sourceFile' => 'C:/Xilinx/12.2/ISE_DS/ISE/sysgen/hdl/xldelay.v',
  };
  push(@$results, &SgDeliverFile::saveCollaborationInfo($instrs));
  $instrs = {
    'entity_declaration_hash' => 'bf321ea258cb94c9f21c40a144333863',
    'sourceFile' => 'C:/Xilinx/12.2/ISE_DS/ISE/sysgen/hdl/xlslice.v',
  };
  push(@$results, &SgDeliverFile::saveCollaborationInfo($instrs));
  $instrs = {
    'entity_declaration_hash' => 'cfcfbcf7e8e0f708aebb83ebbdb5b8a9',
    'sourceFile' => 'C:/Xilinx/12.2/ISE_DS/ISE/sysgen/hdl/xlslice.v',
  };
  push(@$results, &SgDeliverFile::saveCollaborationInfo($instrs));
  $instrs = {
    'entity_declaration_hash' => 'f02444db24f23e42497dc4347750cf70',
    'sourceFile' => 'hdl/xlmcode.v',
    'templateKeyValues' => {
      'crippled_module' => '(
  input [(32 - 1):0] a,
  input [(32 - 1):0] b,
  output [(1 - 1):0] op,
  input clk,
  input ce,
  input clr);
  wire [(32 - 1):0] a_1_31;
  wire [(32 - 1):0] b_1_34;
  localparam [(1 - 1):0] const_value = 1\'b1;
  wire result_16_3_rel;
  assign a_1_31 = a;
  assign b_1_34 = b;
  assign result_16_3_rel = a_1_31 < b_1_34;
  assign op = result_16_3_rel;
endmodule
',
      'entity_name' => 'relational_25d11e84d6',
    },
  };
  push(@$results, &SgDeliverFile::deliverFile($instrs));
  $instrs = {
    'entity_declaration_hash' => '816f973729a5762579d29d194b216eb0',
    'sourceFile' => 'hdl/xlmcode.v',
    'templateKeyValues' => {
      'crippled_module' => '(
  input [(32 - 1):0] a,
  input [(32 - 1):0] b,
  output [(1 - 1):0] op,
  input clk,
  input ce,
  input clr);
  wire [(32 - 1):0] a_1_31;
  wire [(32 - 1):0] b_1_34;
  localparam [(1 - 1):0] const_value = 1\'b1;
  wire result_12_3_rel;
  assign a_1_31 = a;
  assign b_1_34 = b;
  assign result_12_3_rel = a_1_31 == b_1_34;
  assign op = result_12_3_rel;
endmodule
',
      'entity_name' => 'relational_a655552ebd',
    },
  };
  push(@$results, &SgDeliverFile::deliverFile($instrs));
  $instrs = {
    'entity_declaration_hash' => '19fc92a38b3085d563688db0b26f7300',
    'sourceFile' => 'hdl/xlmcode.v',
    'templateKeyValues' => {
      'crippled_module' => '(
  input [(32 - 1):0] a,
  input [(32 - 1):0] b,
  output [(1 - 1):0] op,
  input clk,
  input ce,
  input clr);
  wire [(32 - 1):0] a_1_31;
  wire [(32 - 1):0] b_1_34;
  localparam [(1 - 1):0] const_value = 1\'b1;
  wire result_18_3_rel;
  assign a_1_31 = a;
  assign b_1_34 = b;
  assign result_18_3_rel = a_1_31 > b_1_34;
  assign op = result_18_3_rel;
endmodule
',
      'entity_name' => 'relational_fbc95b256d',
    },
  };
  push(@$results, &SgDeliverFile::deliverFile($instrs));
  $instrs = {
    'entity_declaration_hash' => '9b7ef4c69737f2f39d92e1cbf28f70f1',
    'sourceFile' => 'hdl/xlmcode.v',
    'templateKeyValues' => {
      'crippled_module' => '(
  input [(16 - 1):0] in0,
  input [(16 - 1):0] in1,
  output [(32 - 1):0] y,
  input clk,
  input ce,
  input clr);
  wire [(16 - 1):0] in0_1_23;
  wire [(16 - 1):0] in1_1_27;
  wire [(32 - 1):0] y_2_1_concat;
  assign in0_1_23 = in0;
  assign in1_1_27 = in1;
  assign y_2_1_concat = {in0_1_23, in1_1_27};
  assign y = y_2_1_concat;
endmodule
',
      'entity_name' => 'concat_7e18b92ffa',
    },
  };
  push(@$results, &SgDeliverFile::deliverFile($instrs));
  $instrs = {
    'entity_declaration_hash' => 'b1f93a82a099f3f7f4a3d260b4a92dde',
    'sourceFile' => 'hdl/xlmcode.v',
    'templateKeyValues' => {
      'crippled_module' => '(
  output [(32 - 1):0] op,
  input clk,
  input ce,
  input clr);
  localparam [(32 - 1):0] const_value = 32\'b00000000000000000000000000000000;
  assign op = 32\'b00000000000000000000000000000000;
endmodule
',
      'entity_name' => 'constant_9ac9b740b2',
    },
  };
  push(@$results, &SgDeliverFile::deliverFile($instrs));
  $instrs = {
    'entity_declaration_hash' => '9c83d235d6423637559c42379d11cfc0',
    'sourceFile' => 'hdl/xlmcode.v',
    'templateKeyValues' => {
      'crippled_module' => '(
  output [(2 - 1):0] op,
  input clk,
  input ce,
  input clr);
  localparam [(2 - 1):0] const_value = 2\'b11;
  assign op = 2\'b11;
endmodule
',
      'entity_name' => 'constant_db836c2afe',
    },
  };
  push(@$results, &SgDeliverFile::deliverFile($instrs));
  $instrs = {
    'entity_declaration_hash' => '55ea8779e4ba532361222f4bcbd6f84c',
    'sourceFile' => 'C:/Xilinx/12.2/ISE_DS/ISE/sysgen/hdl/xldelay.v',
  };
  push(@$results, &SgDeliverFile::saveCollaborationInfo($instrs));
  $instrs = {
    'entity_declaration_hash' => '115281f8adee004f80baf19df7f1b5cf',
    'sourceFile' => 'C:/Xilinx/12.2/ISE_DS/ISE/sysgen/hdl/xldelay.v',
  };
  push(@$results, &SgDeliverFile::saveCollaborationInfo($instrs));
  $instrs = {
    'entity_declaration_hash' => 'a0987d7122ad2ff3140c0c19f1a7faac',
    'sourceFile' => 'hdl/xlmcode.v',
    'templateKeyValues' => {
      'crippled_module' => '(
  input [(1 - 1):0] sel,
  input [(32 - 1):0] d0,
  input [(32 - 1):0] d1,
  output [(32 - 1):0] y,
  input clk,
  input ce,
  input clr);
  wire sel_1_20;
  wire [(32 - 1):0] d0_1_24;
  wire [(32 - 1):0] d1_1_27;
  wire [(1 - 1):0] sel_internal_2_1_convert;
  reg [(32 - 1):0] unregy_join_6_1;
  assign sel_1_20 = sel;
  assign d0_1_24 = d0;
  assign d1_1_27 = d1;
  assign sel_internal_2_1_convert = {sel_1_20};
  always @(d0_1_24 or d1_1_27 or sel_internal_2_1_convert)
    begin:proc_switch_6_1
      case (sel_internal_2_1_convert)
        1\'b0 :
          begin
            unregy_join_6_1 = d0_1_24;
          end
        default:
          begin
            unregy_join_6_1 = d1_1_27;
          end
      endcase
    end
  assign y = unregy_join_6_1;
endmodule
',
      'entity_name' => 'mux_413c49a583',
    },
  };
  push(@$results, &SgDeliverFile::deliverFile($instrs));
  $instrs = {
    'entity_declaration_hash' => 'c92fec29337c3f99f4726b6369770671',
    'sourceFile' => 'hdl/xlmcode.v',
    'templateKeyValues' => {
      'crippled_module' => '(
  input [(2 - 1):0] a,
  input [(4 - 1):0] b,
  output [(1 - 1):0] op,
  input clk,
  input ce,
  input clr);
  wire [(2 - 1):0] a_1_31;
  wire [(4 - 1):0] b_1_34;
  localparam [(1 - 1):0] const_value = 1\'b1;
  wire [(4 - 1):0] cast_12_12;
  wire result_12_3_rel;
  assign a_1_31 = a;
  assign b_1_34 = b;
  assign cast_12_12 = {2\'b00, a_1_31[1:0]};
  assign result_12_3_rel = cast_12_12 == b_1_34;
  assign op = result_12_3_rel;
endmodule
',
      'entity_name' => 'relational_b2c5e92584',
    },
  };
  push(@$results, &SgDeliverFile::deliverFile($instrs));
  $instrs = {
    'entity_declaration_hash' => '63c8cb1ab0230a16f1a536bb0042486f',
    'sourceFile' => 'hdl/xlmcode.v',
    'templateKeyValues' => {
      'crippled_module' => '(
  output [(4 - 1):0] op,
  input clk,
  input ce,
  input clr);
  localparam [(4 - 1):0] const_value = 4\'b0000;
  assign op = 4\'b0000;
endmodule
',
      'entity_name' => 'constant_e3acfd4e25',
    },
  };
  push(@$results, &SgDeliverFile::deliverFile($instrs));
  $instrs = {
    'entity_declaration_hash' => '05c56fa8eb50c7a8bce27c62c1bc91ff',
    'sourceFile' => 'hdl/xlmcode.v',
    'templateKeyValues' => {
      'crippled_module' => '(
  output [(1 - 1):0] op,
  input clk,
  input ce,
  input clr);
  assign op = 1\'b0;
endmodule
',
      'entity_name' => 'constant_ae323e07fc',
    },
  };
  push(@$results, &SgDeliverFile::deliverFile($instrs));
  $instrs = {
    'entity_declaration_hash' => '3030a8229429e64e423566fc19af894d',
    'sourceFile' => 'hdl/xlmcode.v',
    'templateKeyValues' => {
      'crippled_module' => '(
  output [(4 - 1):0] op,
  input clk,
  input ce,
  input clr);
  localparam [(4 - 1):0] const_value = 4\'b0011;
  assign op = 4\'b0011;
endmodule
',
      'entity_name' => 'constant_ce9b21eb4c',
    },
  };
  push(@$results, &SgDeliverFile::deliverFile($instrs));
  $instrs = {
    'entity_declaration_hash' => '2ee429d43a4415f7bb3187e559471530',
    'sourceFile' => 'hdl/xlmcode.v',
    'templateKeyValues' => {
      'crippled_module' => '(
  input [(2 - 1):0] sel,
  input [(1 - 1):0] d0,
  input [(1 - 1):0] d1,
  input [(1 - 1):0] d2,
  input [(1 - 1):0] d3,
  output [(1 - 1):0] y,
  input clk,
  input ce,
  input clr);
  wire [(2 - 1):0] sel_1_20;
  wire d0_1_24;
  wire d1_1_27;
  wire d2_1_30;
  wire d3_1_33;
  reg unregy_join_6_1;
  assign sel_1_20 = sel;
  assign d0_1_24 = d0;
  assign d1_1_27 = d1;
  assign d2_1_30 = d2;
  assign d3_1_33 = d3;
  always @(d0_1_24 or d1_1_27 or d2_1_30 or d3_1_33 or sel_1_20)
    begin:proc_switch_6_1
      case (sel_1_20)
        2\'b00 :
          begin
            unregy_join_6_1 = d0_1_24;
          end
        2\'b01 :
          begin
            unregy_join_6_1 = d1_1_27;
          end
        2\'b10 :
          begin
            unregy_join_6_1 = d2_1_30;
          end
        default:
          begin
            unregy_join_6_1 = d3_1_33;
          end
      endcase
    end
  assign y = unregy_join_6_1;
endmodule
',
      'entity_name' => 'mux_86ae73139e',
    },
  };
  push(@$results, &SgDeliverFile::deliverFile($instrs));
  $instrs = {
    'entity_declaration_hash' => '16975b8d20d515f1c604466ce2d68ea5',
    'sourceFile' => 'hdl/xlmcode.v',
    'templateKeyValues' => {
      'crippled_module' => '(
  input [(3 - 1):0] a,
  input [(4 - 1):0] b,
  output [(1 - 1):0] op,
  input clk,
  input ce,
  input clr);
  wire [(3 - 1):0] a_1_31;
  wire [(4 - 1):0] b_1_34;
  localparam [(1 - 1):0] const_value = 1\'b1;
  wire [(4 - 1):0] cast_12_12;
  wire result_12_3_rel;
  assign a_1_31 = a;
  assign b_1_34 = b;
  assign cast_12_12 = {1\'b0, a_1_31[2:0]};
  assign result_12_3_rel = cast_12_12 == b_1_34;
  assign op = result_12_3_rel;
endmodule
',
      'entity_name' => 'relational_de629dc4aa',
    },
  };
  push(@$results, &SgDeliverFile::deliverFile($instrs));
  $instrs = {
    'entity_declaration_hash' => '88e5bcf728b039031a2e11f1ab55ef61',
    'sourceFile' => 'hdl/xlmcode.v',
    'templateKeyValues' => {
      'crippled_module' => '(
  input [(1 - 1):0] sel,
  input [(4 - 1):0] d0,
  input [(2 - 1):0] d1,
  output [(4 - 1):0] y,
  input clk,
  input ce,
  input clr);
  wire sel_1_20;
  wire [(4 - 1):0] d0_1_24;
  wire [(2 - 1):0] d1_1_27;
  wire [(1 - 1):0] sel_internal_2_1_convert;
  reg [(4 - 1):0] unregy_join_6_1;
  assign sel_1_20 = sel;
  assign d0_1_24 = d0;
  assign d1_1_27 = d1;
  assign sel_internal_2_1_convert = {sel_1_20};
  always @(d0_1_24 or d1_1_27 or sel_internal_2_1_convert)
    begin:proc_switch_6_1
      case (sel_internal_2_1_convert)
        1\'b0 :
          begin
            unregy_join_6_1 = d0_1_24;
          end
        default:
          begin
            unregy_join_6_1 = {2\'b00, d1_1_27[1:0]};
          end
      endcase
    end
  assign y = unregy_join_6_1;
endmodule
',
      'entity_name' => 'mux_07adb680a6',
    },
  };
  push(@$results, &SgDeliverFile::deliverFile($instrs));
  $instrs = {
    'entity_declaration_hash' => '90fb7b41a3fb982ba0c76dc7ed26c3b8',
    'sourceFile' => 'hdl/xlmcode.v',
    'templateKeyValues' => {
      'crippled_module' => '(
  input [(1 - 1):0] sel,
  input [(4 - 1):0] d0,
  input [(3 - 1):0] d1,
  output [(4 - 1):0] y,
  input clk,
  input ce,
  input clr);
  wire sel_1_20;
  wire [(4 - 1):0] d0_1_24;
  wire [(3 - 1):0] d1_1_27;
  wire [(1 - 1):0] sel_internal_2_1_convert;
  reg [(4 - 1):0] unregy_join_6_1;
  assign sel_1_20 = sel;
  assign d0_1_24 = d0;
  assign d1_1_27 = d1;
  assign sel_internal_2_1_convert = {sel_1_20};
  always @(d0_1_24 or d1_1_27 or sel_internal_2_1_convert)
    begin:proc_switch_6_1
      case (sel_internal_2_1_convert)
        1\'b0 :
          begin
            unregy_join_6_1 = d0_1_24;
          end
        default:
          begin
            unregy_join_6_1 = {1\'b0, d1_1_27[2:0]};
          end
      endcase
    end
  assign y = unregy_join_6_1;
endmodule
',
      'entity_name' => 'mux_33f57075f0',
    },
  };
  push(@$results, &SgDeliverFile::deliverFile($instrs));
  $instrs = {
    'entity_declaration_hash' => '7790e5be52cf2459d680663b33f9632f',
    'sourceFile' => 'C:/Xilinx/12.2/ISE_DS/ISE/sysgen/hdl/xlslice.v',
  };
  push(@$results, &SgDeliverFile::saveCollaborationInfo($instrs));
  $instrs = {
    'entity_declaration_hash' => '5ea6f9bd67d499313854eb8fb36c5a32',
    'sourceFile' => 'C:/Xilinx/12.2/ISE_DS/ISE/sysgen/hdl/xlslice.v',
  };
  push(@$results, &SgDeliverFile::saveCollaborationInfo($instrs));
  $instrs = {
    'entity_declaration_hash' => '79c9fe4a45500f6c0815221e991f1313',
    'sourceFile' => 'hdl/xlmcode.v',
    'templateKeyValues' => {
      'crippled_module' => '(
  input [(3 - 1):0] a,
  input [(4 - 1):0] b,
  output [(1 - 1):0] op,
  input clk,
  input ce,
  input clr);
  wire [(3 - 1):0] a_1_31;
  wire [(4 - 1):0] b_1_34;
  localparam [(1 - 1):0] const_value = 1\'b1;
  wire [(4 - 1):0] cast_18_12;
  wire result_18_3_rel;
  assign a_1_31 = a;
  assign b_1_34 = b;
  assign cast_18_12 = {1\'b0, a_1_31[2:0]};
  assign result_18_3_rel = cast_18_12 > b_1_34;
  assign op = result_18_3_rel;
endmodule
',
      'entity_name' => 'relational_031c4ff164',
    },
  };
  push(@$results, &SgDeliverFile::deliverFile($instrs));
  $instrs = {
    'entity_declaration_hash' => 'e87e317fda56764062f8c36705cbcd1c',
    'sourceFile' => 'C:/Xilinx/12.2/ISE_DS/ISE/sysgen/hdl/xlslice.v',
  };
  push(@$results, &SgDeliverFile::saveCollaborationInfo($instrs));
  $instrs = {
    'entity_declaration_hash' => 'ae64b018373297cf2ebbfba0e5a75e4c',
    'sourceFile' => 'C:/Xilinx/12.2/ISE_DS/ISE/sysgen/hdl/xlslice.v',
  };
  push(@$results, &SgDeliverFile::saveCollaborationInfo($instrs));
  $instrs = {
    'entity_declaration_hash' => '3344f6b2dd3f5783551518cbec4c3573',
    'sourceFile' => 'hdl/xlmcode.v',
    'templateKeyValues' => {
      'crippled_module' => '(
  input [(1 - 1):0] a,
  input [(1 - 1):0] b,
  output [(1 - 1):0] op,
  input clk,
  input ce,
  input clr);
  wire [(1 - 1):0] a_1_31;
  wire [(1 - 1):0] b_1_34;
  localparam [(1 - 1):0] const_value = 1\'b1;
  wire result_12_3_rel;
  assign a_1_31 = a;
  assign b_1_34 = b;
  assign result_12_3_rel = a_1_31 == b_1_34;
  assign op = result_12_3_rel;
endmodule
',
      'entity_name' => 'relational_8a32119741',
    },
  };
  push(@$results, &SgDeliverFile::deliverFile($instrs));
  $instrs = {
    'entity_declaration_hash' => '4fa11a982bb43df747814358046edbf0',
    'sourceFile' => 'C:/Xilinx/12.2/ISE_DS/ISE/sysgen/hdl/xlslice.v',
  };
  push(@$results, &SgDeliverFile::saveCollaborationInfo($instrs));
  $instrs = {
    'entity_declaration_hash' => 'a21381ab9e6a505bacc2a4496463292b',
    'sourceFile' => 'C:/Xilinx/12.2/ISE_DS/ISE/sysgen/hdl/xlslice.v',
  };
  push(@$results, &SgDeliverFile::saveCollaborationInfo($instrs));
  $instrs = {
    'entity_declaration_hash' => '6ca3c52700fe5fbdcd59d5a9cdb60c2e',
    'sourceFile' => 'hdl/xlmcode.v',
    'templateKeyValues' => {
      'crippled_module' => '(
  output [(2 - 1):0] op,
  input clk,
  input ce,
  input clr);
  localparam [(2 - 1):0] const_value = 2\'b00;
  assign op = 2\'b00;
endmodule
',
      'entity_name' => 'constant_9e0724a33a',
    },
  };
  push(@$results, &SgDeliverFile::deliverFile($instrs));
  $instrs = {
    'entity_declaration_hash' => 'd34303d6919f3543d378f81c12f6f492',
    'sourceFile' => 'hdl/xlmcode.v',
    'templateKeyValues' => {
      'crippled_module' => '(
  input [(4 - 1):0] in0,
  input [(4 - 1):0] in1,
  input [(4 - 1):0] in2,
  input [(4 - 1):0] in3,
  output [(16 - 1):0] y,
  input clk,
  input ce,
  input clr);
  wire [(4 - 1):0] in0_1_23;
  wire [(4 - 1):0] in1_1_27;
  wire [(4 - 1):0] in2_1_31;
  wire [(4 - 1):0] in3_1_35;
  wire [(16 - 1):0] y_2_1_concat;
  assign in0_1_23 = in0;
  assign in1_1_27 = in1;
  assign in2_1_31 = in2;
  assign in3_1_35 = in3;
  assign y_2_1_concat = {in0_1_23, in1_1_27, in2_1_31, in3_1_35};
  assign y = y_2_1_concat;
endmodule
',
      'entity_name' => 'concat_583d259828',
    },
  };
  push(@$results, &SgDeliverFile::deliverFile($instrs));
  $instrs = {
    'entity_declaration_hash' => 'e249a659aa476ba4be5f56be7d883c0e',
    'sourceFile' => 'hdl/xlmcode.v',
    'templateKeyValues' => {
      'crippled_module' => '(
  input [(1 - 1):0] d0,
  input [(1 - 1):0] d1,
  input [(1 - 1):0] d2,
  input [(1 - 1):0] d3,
  input [(1 - 1):0] d4,
  input [(1 - 1):0] d5,
  input [(1 - 1):0] d6,
  input [(1 - 1):0] d7,
  output [(1 - 1):0] y,
  input clk,
  input ce,
  input clr);
  wire d0_1_24;
  wire d1_1_27;
  wire d2_1_30;
  wire d3_1_33;
  wire d4_1_36;
  wire d5_1_39;
  wire d6_1_42;
  wire d7_1_45;
  wire fully_2_1_bit;
  assign d0_1_24 = d0;
  assign d1_1_27 = d1;
  assign d2_1_30 = d2;
  assign d3_1_33 = d3;
  assign d4_1_36 = d4;
  assign d5_1_39 = d5;
  assign d6_1_42 = d6;
  assign d7_1_45 = d7;
  assign fully_2_1_bit = d0_1_24 | d1_1_27 | d2_1_30 | d3_1_33 | d4_1_36 | d5_1_39 | d6_1_42 | d7_1_45;
  assign y = fully_2_1_bit;
endmodule
',
      'entity_name' => 'logical_a31ec052ba',
    },
  };
  push(@$results, &SgDeliverFile::deliverFile($instrs));
  $instrs = {
    'entity_declaration_hash' => '7c1e7407b5175aaddc10cb8ceb8921ba',
    'sourceFile' => 'hdl/xlmcode.v',
    'templateKeyValues' => {
      'crippled_module' => '(
  output [(3 - 1):0] op,
  input clk,
  input ce,
  input clr);
  localparam [(3 - 1):0] const_value = 3\'b100;
  assign op = 3\'b100;
endmodule
',
      'entity_name' => 'constant_d2d23930f4',
    },
  };
  push(@$results, &SgDeliverFile::deliverFile($instrs));
  $instrs = {
    'entity_declaration_hash' => 'e005f3d110b10958e840a270bb2b4d09',
    'sourceFile' => 'hdl/xlmcode.v',
    'templateKeyValues' => {
      'crippled_module' => '(
  output [(18 - 1):0] op,
  input clk,
  input ce,
  input clr);
  localparam [(18 - 1):0] const_value = 18\'b100000000000000000;
  assign op = 18\'b100000000000000000;
endmodule
',
      'entity_name' => 'constant_e1b037590b',
    },
  };
  push(@$results, &SgDeliverFile::deliverFile($instrs));
  $instrs = [
    'SELECT Binary_Counter spartan3 Xilinx,_Inc. 11.0',
    '# 12.2',
    '# DEVICE spartan3',
    'CSET ainit_value = 0',
    'CSET ce = true',
    'CSET count_mode = UP',
    'CSET fb_latency = 0',
    'CSET final_count_value = 1',
    'CSET implementation = Fabric',
    'CSET increment_value = 1',
    'CSET latency = 1',
    'CSET load = false',
    'CSET output_width = 18',
    'CSET restrict_count = false',
    'CSET sclr = false',
    'CSET sinit = true',
    'CSET sinit_value = 0',
    'CSET sset = false',
    'CSET sync_ce_priority = Sync_Overrides_CE',
    'CSET sync_threshold_output = false',
    'CSET syncctrlpriority = Reset_Overrides_Set',
    'CSET component_name = cntr_11_0_6d56c2a508c4e854',
    'GENERATE',
  ];
  push(@$results, &SgGenerateCores::saveXcoSequence($instrs));
  $instrs = {
    'entity_declaration_hash' => '9706b4cea9d0e576aaf8bf8bb49844e9',
    'sourceFile' => 'hdl/xlcounter_free.v',
    'templateKeyValues' => {
      'core_instance_text' => '        .clk(clk),
        .ce(core_ce),
        .sinit(core_sinit),
        .q(op_net)',
      'core_name0' => 'cntr_11_0_6d56c2a508c4e854',
      'entity_name.0' => 'xlcounter_free',
      'needs_core' => 1,
    },
  };
  push(@$results, &SgDeliverFile::saveCollaborationInfo($instrs));
  $instrs = [
    'SELECT Binary_Counter spartan3 Xilinx,_Inc. 11.0',
    '# 12.2',
    '# DEVICE spartan3',
    'CSET ainit_value = 0',
    'CSET ce = true',
    'CSET count_mode = UP',
    'CSET fb_latency = 0',
    'CSET final_count_value = 1',
    'CSET implementation = Fabric',
    'CSET increment_value = 1',
    'CSET latency = 1',
    'CSET load = false',
    'CSET output_width = 10',
    'CSET restrict_count = false',
    'CSET sclr = false',
    'CSET sinit = true',
    'CSET sinit_value = 0',
    'CSET sset = false',
    'CSET sync_ce_priority = Sync_Overrides_CE',
    'CSET sync_threshold_output = false',
    'CSET syncctrlpriority = Reset_Overrides_Set',
    'CSET component_name = cntr_11_0_166924cf61cffc7c',
    'GENERATE',
  ];
  push(@$results, &SgGenerateCores::saveXcoSequence($instrs));
  $instrs = {
    'entity_declaration_hash' => '27b5befd90598402753dc7c1dc41bd43',
    'sourceFile' => 'hdl/xlcounter_free.v',
    'templateKeyValues' => {
      'core_instance_text' => '        .clk(clk),
        .ce(core_ce),
        .sinit(core_sinit),
        .q(op_net)',
      'core_name0' => 'cntr_11_0_166924cf61cffc7c',
      'entity_name.0' => 'xlcounter_free',
      'needs_core' => 1,
    },
  };
  push(@$results, &SgDeliverFile::saveCollaborationInfo($instrs));
  $instrs = {
    'entity_declaration_hash' => '95afd146005dd1d1bef8615373a20c7b',
    'sourceFile' => 'hdl/xlmcode.v',
    'templateKeyValues' => {
      'crippled_module' => '(
  input [(1 - 1):0] sel,
  input [(5 - 1):0] d0,
  input [(5 - 1):0] d1,
  output [(5 - 1):0] y,
  input clk,
  input ce,
  input clr);
  wire sel_1_20;
  wire [(5 - 1):0] d0_1_24;
  wire [(5 - 1):0] d1_1_27;
  wire [(1 - 1):0] sel_internal_2_1_convert;
  reg [(5 - 1):0] unregy_join_6_1;
  assign sel_1_20 = sel;
  assign d0_1_24 = d0;
  assign d1_1_27 = d1;
  assign sel_internal_2_1_convert = {sel_1_20};
  always @(d0_1_24 or d1_1_27 or sel_internal_2_1_convert)
    begin:proc_switch_6_1
      case (sel_internal_2_1_convert)
        1\'b0 :
          begin
            unregy_join_6_1 = d0_1_24;
          end
        default:
          begin
            unregy_join_6_1 = d1_1_27;
          end
      endcase
    end
  assign y = unregy_join_6_1;
endmodule
',
      'entity_name' => 'mux_98961f42cb',
    },
  };
  push(@$results, &SgDeliverFile::deliverFile($instrs));
  $instrs = {
    'entity_declaration_hash' => '6e73824eb0992f078deb48337fec5b87',
    'sourceFile' => 'hdl/xlmcode.v',
    'templateKeyValues' => {
      'crippled_module' => '(
  input [(18 - 1):0] a,
  input [(18 - 1):0] b,
  output [(1 - 1):0] op,
  input clk,
  input ce,
  input clr);
  wire [(18 - 1):0] a_1_31;
  wire [(18 - 1):0] b_1_34;
  localparam [(1 - 1):0] const_value = 1\'b1;
  wire result_18_3_rel;
  assign a_1_31 = a;
  assign b_1_34 = b;
  assign result_18_3_rel = a_1_31 > b_1_34;
  assign op = result_18_3_rel;
endmodule
',
      'entity_name' => 'relational_cf091b8cb2',
    },
  };
  push(@$results, &SgDeliverFile::deliverFile($instrs));
  $instrs = {
    'entity_declaration_hash' => '42910a30668f218b8cb0744c3c3fa923',
    'sourceFile' => 'C:/Xilinx/12.2/ISE_DS/ISE/sysgen/hdl/xlslice.v',
  };
  push(@$results, &SgDeliverFile::saveCollaborationInfo($instrs));
  $instrs = {
    'entity_declaration_hash' => '7cb1604b002529a1e85922040621510b',
    'sourceFile' => 'C:/Xilinx/12.2/ISE_DS/ISE/sysgen/hdl/xlslice.v',
  };
  push(@$results, &SgDeliverFile::saveCollaborationInfo($instrs));
  $instrs = {
    'entity_declaration_hash' => 'b2298ef332f9b14914560c235ef24232',
    'sourceFile' => 'C:/Xilinx/12.2/ISE_DS/ISE/sysgen/hdl/xlusamp.v',
  };
  push(@$results, &SgDeliverFile::saveCollaborationInfo($instrs));
  local *wrapup = $Sg::{'wrapup'};
  push(@$results, &Sg::wrapup())   if (defined(&wrapup));
  local *wrapup = $SgDeliverFile::{'wrapup'};
  push(@$results, &SgDeliverFile::wrapup())   if (defined(&wrapup));
  local *wrapup = $SgGenerateCores::{'wrapup'};
  push(@$results, &SgGenerateCores::wrapup())   if (defined(&wrapup));
  use Carp qw(croak);
  $ENV{'SYSGEN'} = 'C:/Xilinx/12.2/ISE_DS/ISE/sysgen';
  open(RESULTS, '> G:/Projekte/wireless_firewall/dschung/IEEE 802.15.4 receiver/receiver_overall_reset/sysgen/script_results8549517139595606300') || 
    croak 'couldn\'t open G:/Projekte/wireless_firewall/dschung/IEEE 802.15.4 receiver/receiver_overall_reset/sysgen/script_results8549517139595606300';
  binmode(RESULTS);
  print RESULTS &Sg::toString($results) . "\n";
  close(RESULTS) || 
    croak 'trouble writing G:/Projekte/wireless_firewall/dschung/IEEE 802.15.4 receiver/receiver_overall_reset/sysgen/script_results8549517139595606300';
};

if ($@) {
  open(RESULTS, '> G:/Projekte/wireless_firewall/dschung/IEEE 802.15.4 receiver/receiver_overall_reset/sysgen/script_results8549517139595606300') || 
    croak 'couldn\'t open G:/Projekte/wireless_firewall/dschung/IEEE 802.15.4 receiver/receiver_overall_reset/sysgen/script_results8549517139595606300';
  binmode(RESULTS);
  print RESULTS $@ . "\n";
  close(RESULTS) || 
    croak 'trouble writing G:/Projekte/wireless_firewall/dschung/IEEE 802.15.4 receiver/receiver_overall_reset/sysgen/script_results8549517139595606300';
  exit(1);
}

exit(0);
